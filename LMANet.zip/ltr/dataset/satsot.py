import os
import os.path
import torch
import numpy as np
import pandas
import csv
import random
from collections import OrderedDict
from .base_video_dataset import BaseVideoDataset
from ltr.data.image_loader import jpeg4py_loader
from ltr.admin.environment import env_settings
import io

class Satsot(BaseVideoDataset):
    """ LaSOT dataset.

    Publication:
        LaSOT: A High-quality Benchmark for Large-scale Single Object Tracking
        Heng Fan, Liting Lin, Fan Yang, Peng Chu, Ge Deng, Sijia Yu, Hexin Bai, Yong Xu, Chunyuan Liao and Haibin Ling
        CVPR, 2019
        https://arxiv.org/pdf/1809.07845.pdf

    Download the dataset from https://cis.temple.edu/lasot/download.html
    """

    def __init__(self, root=None, image_loader=jpeg4py_loader, vid_ids=None, split=None, data_fraction=None):
        """
        args:
            root - path to the lasot dataset.
            image_loader (jpeg4py_loader) -  The function to read the images. jpeg4py (https://github.com/ajkxyz/jpeg4py)
                                            is used by default.
            vid_ids - List containing the ids of the videos (1 - 20) used for training. If vid_ids = [1, 3, 5], then the
                    videos with subscripts -1, -3, and -5 from each class will be used for training.
            split - If split='train', the official train split (protocol-II) is used for training. Note: Only one of
                    vid_ids or split option can be used at a time.
            data_fraction - Fraction of dataset to be used. The complete dataset is used by default
        """
        root = env_settings().satsot_dir if root is None else root
        super().__init__('Satsot', root, image_loader)

        # Keep a list of all classes
        self.class_list = list(set([f.split('_')[0] for f in os.listdir(self.root) if f != 'SatSOT.json']))
        self.class_to_id = {cls_name: cls_id for cls_id, cls_name in enumerate(self.class_list)}

        #self.sequence_list = self._build_sequence_list(vid_ids, split)
        self.sequence_list=[i for i in os.listdir(self.root) if i !='SatSOT.json']

        if data_fraction is not None:
            self.sequence_list = random.sample(self.sequence_list, int(len(self.sequence_list)*data_fraction))

        self.seq_per_class = self._build_class_list()

    # def _build_sequence_list(self, vid_ids=None, split=None):
    #     if split is not None:
    #         if vid_ids is not None:
    #             raise ValueError('Cannot set both split_name and vid_ids.')
    #         ltr_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), '..')
    #         if split == 'train':
    #             file_path = os.path.join(ltr_path, 'data_specs', 'satsot_train_split.txt')
    #         elif split=='val':
    #             file_path = os.path.join(ltr_path, 'data_specs', 'satsot_val_split.txt')
    #         sequence_list = pandas.read_csv(file_path, header=None, squeeze=True).values.tolist()
    #     elif vid_ids is not None:
    #         sequence_list = [c+'-'+str(v) for c in self.class_list for v in vid_ids]
    #     else:
    #         raise ValueError('Set either split_name or vid_ids.')

    #     return sequence_list

    def _build_class_list(self):
        seq_per_class = {}
        #{'airplane': [0, 1, 2, 3, 4, 5],'air':[1,1]}
        for seq_id, seq_name in enumerate(self.sequence_list):
            class_name = seq_name.split('_')[0]
            if class_name in seq_per_class:
                seq_per_class[class_name].append(seq_id)
            else:
                seq_per_class[class_name] = [seq_id]

        return seq_per_class

    def get_name(self):
        return 'SatSOT'

    def has_class_info(self):
        return True

    def has_occlusion_info(self):
        return True

    def get_num_sequences(self):
        return len(self.sequence_list)

    def get_num_classes(self):
        return len(self.class_list)

    def get_sequences_in_class(self, class_name):
        return self.seq_per_class[class_name]

    
    def _read_bb_anno(self, seq_path,seq_id):
        #/home/lcl_d/zhaoxingle/dataset/sot/car/001/
        #seq_name = self.sequence_list[seq_id]
        #anno_name=seq_name.split("-")[2]+'_'+seq_name.split("-")[3]+'_'+seq_name.split("-")[4]+'.txt'
        bb_anno_file = os.path.join(seq_path,'groundtruth.txt')
       
                #gt = np.loadtxt(io.StringIO(f.read().replace(',', ' ')), converters={0:check})
        #gt = np.loadtxt(bb_anno_file)
        try:
            gt = pandas.read_csv(bb_anno_file, delimiter=',',dtype=np.float32, header=None, na_filter=False, low_memory=False).values
        except:
            print(bb_anno_file)
        return torch.tensor(gt),bb_anno_file

    def _read_target_visible(self, seq_path,seq_id):
        # Read full occlusion and out_of_view
        # occlusion_file = os.path.join(seq_path, "full_occlusion.txt")
        # out_of_view_file = os.path.join(seq_path, "out_of_view.txt")

        # with open(occlusion_file, 'r', newline='') as f:
        #     occlusion = torch.ByteTensor([int(v) for v in list(csv.reader(f))[0]])
        # with open(out_of_view_file, 'r') as f:
        #     out_of_view = torch.ByteTensor([int(v) for v in list(csv.reader(f))[0]])

        # target_visible = ~occlusion & ~out_of_view

        #获得路径名 'car-011-85-166-220'
        seq_name = self.sequence_list[seq_id]
        class_name = seq_name.split('-')[0]
        vid_id = seq_name.split('-')[1]
        start_frame=seq_name.split('-')[-2]
        end_frame=seq_name.split('-')[-1]
        #self.root'/home/lcl_d/zhaoxingle/dataset/sot/car/1' car-1-1-1-260

        path=os.path.join(seq_path,'img')
        #path=r'/home/lcl_d/zhaoxingle/dataset/sot/car/017/img'
        list=os.listdir(path)
        a=len(list) #总的帧数

        occlusion=torch.zeros(a,dtype=torch.uint8)
        out_of_view = torch.zeros(a,dtype=torch.uint8)
        for i in range(start_frame,end_frame+1):
            out_of_view[i-1]=1
        target_visible = ~occlusion & ~out_of_view
        #visible_ratio = cover.float() / 8
        #return target_visible, visible_ratio

        return target_visible

    def _get_sequence_path(self, seq_id):
        #获得路径名 'car-011-85-166-220'
        seq_name = self.sequence_list[seq_id]
        class_name = seq_name.split('_')[0]
        vid_id = seq_name.split('_')[1]
        #self.root'/home/lcl_d/zhaoxingle/dataset/sot/car/1' car-1-1-1-260
        return os.path.join(self.root, seq_name)

    def get_sequence_info(self, seq_id):
        seq_path = self._get_sequence_path(seq_id)
        bbox ,bb_anno_file = self._read_bb_anno(seq_path,seq_id)
        #i=0
        temp=[]
        for i in range(bbox.shape[0]):
            if bbox[i].numpy()[0]==0 and bbox[i].numpy()[1]==0 and bbox[i].numpy()[2]==0 and bbox[i].numpy()[3]==0:
                temp.append(i)
        visible=torch.ones(bbox.shape[0],dtype=int)
        for i in range(len(temp)):
            visible[temp[i]]=0
        return {'bbox': bbox, 'valid': visible, 'visible': visible},bb_anno_file

    def _get_frame_path(self, seq_path, frame_id,seq_id):
        #car-1-1-1-260
        seq_name = self.sequence_list[seq_id]
        #start_frame = seq_name.split('-')[-2]
        #end_frame = seq_name.split('-')[-1]
        #frame_id=int(frame_id)+int(start_frame)-1
        return os.path.join(seq_path, 'img', '{:04}.jpg'.format(frame_id+1))    # frames start from 1

    def _get_frame(self, seq_path, frame_id,seq_id):
        return self.image_loader(self._get_frame_path(seq_path, frame_id,seq_id))

    def _get_class(self, seq_path):
        raw_class = seq_path.split('/')[-1].split('_')[0]
        return raw_class

    def get_class_name(self, seq_id):
        seq_path = self._get_sequence_path(seq_id)
        obj_class = self._get_class(seq_path)

        return obj_class

    def get_frames(self, seq_id, frame_ids, anno=None):

        seq_path = self._get_sequence_path(seq_id)

        obj_class = self._get_class(seq_path)
        frame_list = [self._get_frame(seq_path, f_id,seq_id) for f_id in frame_ids]
        
        anno,bb_path = self.get_sequence_info(seq_id)
        if anno is None:
            anno,bb_path = self.get_sequence_info(seq_id)

        anno_frames = {}
        for key, value in anno.items():
            anno_frames[key] = [value[f_id, ...].clone() for f_id in frame_ids]

        object_meta = OrderedDict({'object_class_name': obj_class,
                                   'motion_class': None,
                                   'major_class': None,
                                   'root_class': None,
                                   'motion_adverb': None},
                                   )

        #return frame_list, anno_frames, object_meta,bb_path
        return frame_list, anno_frames, object_meta
