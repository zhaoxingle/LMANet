class EnvironmentSettings:
    def __init__(self):
        self.viso_dir = '/media/data2/zhaoxingle/sot/'
        self.workspace_dir = '/home/lcl_d/zhaoxingle/pytracking_tomp/1orign_tomp/pytracking/ltr'    # Base directory for saving network checkpoints.
        self.tensorboard_dir = self.workspace_dir + '/tensorboard/'    # Directory for tensorboard files.
        self.pretrained_networks = self.workspace_dir + '/pretrained_networks/'
        self.lasot_dir = '/media/data2/zhaoxingle/LaSOT/LaSOT/LaSOTBenchmark'
        self.got10k_dir = '/media/data2/wangzhanghuan/Dataset/GOT-10k/train/'
        self.trackingnet_dir = '/media/data2/zhaoxingle/TrackingNet/'
        self.coco_dir = '/media/data2/zhaoxingle/coco'
        self.lvis_dir = ''
        self.sbd_dir = ''
        self.imagenet_dir = ''
        self.imagenetdet_dir = ''
        self.ecssd_dir = ''
        self.hkuis_dir = ''
        self.msra10k_dir = ''
        self.davis_dir = ''
        self.youtubevos_dir = ''
        self.lasot_candidate_matching_dataset_path = ''
