import math
import torch.nn as nn
from collections import OrderedDict
import torch.utils.model_zoo as model_zoo
from torchvision.models.resnet import model_urls
from .base import Backbone
import torch

#
import torch
import torch.nn as nn
import math
from timm.models.layers import DropPath, to_2tuple, trunc_normal_


def conv3x3(in_planes, out_planes, stride=1, dilation=1):
    """3x3 convolution with padding"""
    return nn.Conv2d(in_planes, out_planes, kernel_size=3, stride=stride,
                     padding=dilation, bias=False, dilation=dilation)


class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, inplanes, planes, stride=1, downsample=None, dilation=1, u=True):
        super(BasicBlock, self).__init__()
        self.use_bn = use_bn
        self.conv1 = conv3x3(inplanes, planes, stride, dilation=dilation)

        if use_bn:
            self.bn1 = nn.BatchNorm2d(planes)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = conv3x3(planes, planes, dilation=dilation)

        if use_bn:
            self.bn2 = nn.BatchNorm2d(planes)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        residual = x

        out = self.conv1(x)

        if self.use_bn:
            out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)

        if self.use_bn:
            out = self.bn2(out)

        if self.downsample is not None:
            residual = self.downsample(x)

        out += residual
        out = self.relu(out)

        return out


# class CrossScalePatchEmbed(nn.Module):
#     def __init__(self, in_dims=[16,32,64], embed_dim=768):
#         super().__init__()
#         base_dim = in_dims[0]

#         layers = []
#         for i in range(len(in_dims)):
#             for j in range(2 ** i):
#                 layers.append(nn.Conv2d(in_dims[-1-i], base_dim, 3, 2**(i+1), 1+j, 1+j))
#         self.layers = nn.ModuleList(layers)
#         self.proj = nn.Conv2d(base_dim * len(layers), embed_dim, 1, 1)
#         self.norm = nn.LayerNorm(embed_dim)

#         self.apply(self._init_weights)

#     def _init_weights(self, m):
#         if isinstance(m, nn.Linear):
#             trunc_normal_(m.weight, std=.02)
#             if isinstance(m, nn.Linear) and m.bias is not None:
#                 nn.init.constant_(m.bias, 0)
#         elif isinstance(m, nn.LayerNorm):
#             nn.init.constant_(m.bias, 0)
#             nn.init.constant_(m.weight, 1.0)
#         elif isinstance(m, nn.Conv2d):
#             fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
#             fan_out //= m.groups
#             m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
#             if m.bias is not None:
#                 m.bias.data.zero_()

#     def forward(self, xs):
#         ys = []
#         k = 0
#         for i in range(len(xs)):
#             for _ in range(2 ** i):
#                 ys.append(self.layers[k](xs[-1-i]))
#                 k += 1
#         x = self.proj(torch.cat(ys,1))#torch.Size([2, 112, 60, 107])
#         _, _, H, W = x.shape
#         x = x.flatten(2).transpose(1, 2) #torch.Size([2, 128, 60, 107])
#         x = self.norm(x)

#         return x, H, W
# class OverlapPatchEmbed(nn.Module):
#     def __init__(self, patch_size=7, stride=4, in_chans=3, embed_dim=768):
#         super().__init__()
#         patch_size = to_2tuple(patch_size)

#         self.patch_size = patch_size
#         self.proj = nn.Conv2d(in_chans, embed_dim, kernel_size=patch_size, stride=stride,
#                               padding=(patch_size[0] // 2, patch_size[1] // 2))
#         self.norm = nn.LayerNorm(embed_dim)

#         self.apply(self._init_weights)

#     def _init_weights(self, m):
#         if isinstance(m, nn.Linear):
#             trunc_normal_(m.weight, std=.02)
#             if isinstance(m, nn.Linear) and m.bias is not None:
#                 nn.init.constant_(m.bias, 0)
#         elif isinstance(m, nn.LayerNorm):
#             nn.init.constant_(m.bias, 0)
#             nn.init.constant_(m.weight, 1.0)
#         elif isinstance(m, nn.Conv2d):
#             fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
#             fan_out //= m.groups
#             m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
#             if m.bias is not None:
#                 m.bias.data.zero_()

#     def forward(self, x):
#         x = self.proj(x)
#         _, _, H, W = x.shape
#         x = x.flatten(2).transpose(1, 2)
#         x = self.norm(x)

#         return x, H, W
class Bottleneck(nn.Module):
    expansion = 4

    def __init__(self, inplanes, planes, stride=1, downsample=None, dilation=1):
        super(Bottleneck, self).__init__()
        self.conv1 = nn.Conv2d(inplanes, planes, kernel_size=1, bias=False)
        self.bn1 = nn.BatchNorm2d(planes)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, stride=stride,
                               padding=dilation, bias=False, dilation=dilation)
        self.bn2 = nn.BatchNorm2d(planes)
        self.conv3 = nn.Conv2d(planes, planes * 4, kernel_size=1, bias=False)
        self.bn3 = nn.BatchNorm2d(planes * 4)
        self.relu = nn.ReLU(inplace=True)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        residual = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)
        out = self.relu(out)

        out = self.conv3(out)
        out = self.bn3(out)

        if self.downsample is not None:
            residual = self.downsample(x)

        out += residual
        out = self.relu(out)

        return out


class InterFrameAttention(nn.Module):
    def __init__(self, dim, motion_dim, num_heads=8, qkv_bias=False, qk_scale=None, attn_drop=0., proj_drop=0.):
        super().__init__()
        assert dim % num_heads == 0, f"dim {dim} should be divided by num_heads {num_heads}."

        self.dim = dim
        self.motion_dim = motion_dim
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = qk_scale or head_dim ** -0.5

        self.q = nn.Linear(dim, dim, bias=qkv_bias)
        self.kv = nn.Linear(dim, dim * 2, bias=qkv_bias)
        self.cor_embed = nn.Linear(2, motion_dim, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        #self.proj = nn.Linear(dim, dim)
        self.motion_proj = nn.Linear(motion_dim, motion_dim)
        #self.proj_drop = nn.Dropout(proj_drop)
        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def forward(self, x1, x2, cor, H, W, mask=None):
        B, N, C = x1.shape  # torch.Size([5184/2, 36, 256]) 36是6*6窗口大小
        B, N, C_c = cor.shape
        q = self.q(x1).reshape(B, N, self.num_heads, C // self.num_heads).permute(0, 2, 1,
                                                                                  3)  # torch.Size([288, 4, 49, 32])
        kv = self.kv(x2).reshape(B, -1, 2, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1,
                                                                                        4)  # torch.Size([2, 288, 4, 49, 32])
        #cor_embed_ = self.cor_embed(cor)[:B]
        cor_embed_ = self.cor_embed(cor)#torch.Size([2592, 36, 2])
        cor_embed = cor_embed_.reshape(B, N, self.num_heads, self.motion_dim // self.num_heads).permute(0, 2, 1, 3)
        #cor_embed = cor_embed_.reshape(B, N, self.num_heads, self.motion_dim // self.num_heads).permute(0, 2, 1, 3)[:B]
        k, v = kv[0], kv[1]
        attn = (q @ k.transpose(-2, -1)) * self.scale#e([144, 2, 36, 36]) 144个窗口，2个头，每个头都会得到每个窗口内的注意力图

        if mask is not None:
            nW = mask.shape[0]  # mask: nW, N, N
            attn = attn.view(B // nW, nW, self.num_heads, N, N) + mask.unsqueeze(
                1
            ).unsqueeze(0)
            attn = attn.view(-1, self.num_heads, N, N)
            attn = attn.softmax(dim=-1)
        else:
            attn = attn.softmax(dim=-1)

        attn = self.attn_drop(attn)
        #x = (attn @ v).transpose(1, 2).reshape(B, N, C)
        c_reverse = (attn @ cor_embed).transpose(1, 2).reshape(B, N, -1)
        motion = self.motion_proj(c_reverse - cor_embed_)
        #x = self.proj(x)
        #x = self.proj_drop(x)
        return motion


# class MotionFormer(nn.Module):
#     def __init__(self, in_chans=3, embed_dims=[32, 64, 128, 256, 512], motion_dims=64, num_heads=[8, 16], 
#                  mlp_ratios=[4, 4], qkv_bias=True, qk_scale=None, drop_rate=0.,
#                  attn_drop_rate=0., drop_path_rate=0., norm_layer=nn.LayerNorm,
#                  depths=[2, 2, 2, 6, 2], window_sizes=[11, 11],**kwarg):
#         super().__init__()
#         self.depths = depths
#         self.num_stages = len(embed_dims)

#         dpr = [x.item() for x in torch.linspace(0, drop_path_rate, sum(depths))]  # stochastic depth decay rule
#         cur = 0

#         self.conv_stages = self.num_stages - len(num_heads)

#         for i in range(self.num_stages):
#             if i == 0:
#                 block = ConvBlock(in_chans,embed_dims[i],depths[i])
#             else:
#                 if i < self.conv_stages:
#                     patch_embed = nn.Sequential(
#                         nn.Conv2d(embed_dims[i-1], embed_dims[i], 3,2,1),
#                         nn.PReLU(embed_dims[i])
#                     )
#                     block = ConvBlock(embed_dims[i],embed_dims[i],depths[i])
#                 else:
#                     if i == self.conv_stages:
#                         patch_embed = CrossScalePatchEmbed(embed_dims[:i],
#                                                         embed_dim=embed_dims[i])
#                     else:
#                         patch_embed = OverlapPatchEmbed(patch_size=3,
#                                                         stride=2,
#                                                         in_chans=embed_dims[i - 1],
#                                                         embed_dim=embed_dims[i])

#                     block = nn.ModuleList([MotionFormerBlock(
#                         dim=embed_dims[i], motion_dim=motion_dims[i], num_heads=num_heads[i-self.conv_stages], window_size=window_sizes[i-self.conv_stages], 
#                         shift_size= 0 if (j % 2) == 0 else window_sizes[i-self.conv_stages] // 2,
#                         mlp_ratio=mlp_ratios[i-self.conv_stages], qkv_bias=qkv_bias, qk_scale=qk_scale,
#                         drop=drop_rate, attn_drop=attn_drop_rate, drop_path=dpr[cur + j], norm_layer=norm_layer)
#                         for j in range(depths[i])])

#                     norm = norm_layer(embed_dims[i])
#                     setattr(self, f"norm{i + 1}", norm)
#                 setattr(self, f"patch_embed{i + 1}", patch_embed)
#             cur += depths[i]

#             setattr(self, f"block{i + 1}", block)

#         self.cor = {}

#         self.apply(self._init_weights)

#     def _init_weights(self, m):
#         if isinstance(m, nn.Linear):
#             trunc_normal_(m.weight, std=.02)
#             if isinstance(m, nn.Linear) and m.bias is not None:
#                 nn.init.constant_(m.bias, 0)
#         elif isinstance(m, nn.LayerNorm):
#             nn.init.constant_(m.bias, 0)
#             nn.init.constant_(m.weight, 1.0)
#         elif isinstance(m, nn.Conv2d):
#             fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
#             fan_out //= m.groups
#             m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
#             if m.bias is not None:
#                 m.bias.data.zero_()

#     def get_cor(self, shape, device):
#         k = (str(shape), str(device))
#         if k not in self.cor:
#             tenHorizontal = torch.linspace(-1.0, 1.0, shape[2], device=device).view(
#                 1, 1, 1, shape[2]).expand(shape[0], -1, shape[1], -1).permute(0, 2, 3, 1)
#             tenVertical = torch.linspace(-1.0, 1.0, shape[1], device=device).view(
#                 1, 1, shape[1], 1).expand(shape[0], -1, -1, shape[2]).permute(0, 2, 3, 1)
#             self.cor[k] = torch.cat([tenHorizontal, tenVertical], -1).to(device)
#         return self.cor[k]

#     def forward(self, x1, x2): #torch.Size([1, 3, 480, 854])
#         B = x1.shape[0] #1
#         x = torch.cat([x1, x2], 0) #torch.Size([2, 3, 480, 854])
#         motion_features = []
#         appearence_features = []
#         xs = []
#         for i in range(self.num_stages):#5
#             motion_features.append([])
#             patch_embed = getattr(self, f"patch_embed{i + 1}",None)
#             block = getattr(self, f"block{i + 1}",None)
#             norm = getattr(self, f"norm{i + 1}",None)
#             if i < self.conv_stages:
#                 if i > 0:
#                     x = patch_embed(x)# torch.Size([2, 32, 240, 427])
#                 x = block(x) #([2, 3, 480, 854])-->([2, 16, 480, 854])
#                 xs.append(x)
#             else:
#                 if i == self.conv_stages:
#                     x, H, W = patch_embed(xs)  #xs[0]torch.Size([2, 16, 480, 854]) #x.shape torch.Size([2, 6420, 128]) H60 W107
#                 else:
#                     x, H, W = patch_embed(x)
#                 cor = self.get_cor((x.shape[0], H, W), x.device) #torch.Size([2, 60, 107, 2])
#                 for blk in block:
#                     x, x_motion = blk(x, cor, H, W, B)#B=1
#                     motion_features[i].append(x_motion.reshape(2*B, H, W, -1).permute(0, 3, 1, 2).contiguous())
#                 x = norm(x)
#                 x = x.reshape(2*B, H, W, -1).permute(0, 3, 1, 2).contiguous()
#                 motion_features[i] = torch.cat(motion_features[i], 1)
#             appearence_features.append(x)
#         return appearence_features, motion_features
class Mlp(nn.Module):
    def __init__(self, in_features, hidden_features=None, out_features=None, act_layer=nn.GELU, drop=0.):
        super().__init__()
        out_features = out_features or in_features
        hidden_features = hidden_features or in_features
        self.fc1 = nn.Linear(in_features, hidden_features)
        self.dwconv = DWConv(hidden_features)
        self.act = act_layer()
        self.fc2 = nn.Linear(hidden_features, out_features)
        self.drop = nn.Dropout(drop)
        self.relu = nn.ReLU(inplace=True)
        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def forward(self, x, H, W):
        x = self.fc1(x)
        x = self.dwconv(x, H, W)
        x = self.act(x)
        x = self.drop(x)
        x = self.fc2(x)
        x = self.drop(x)
        return x


class MotionFormerBlock(nn.Module):
    def __init__(self, dim, motion_dim, num_heads, window_size=0, shift_size=0, mlp_ratio=4., bidirectional=True,
                 qkv_bias=False, qk_scale=None, drop=0., attn_drop=0.,
                 drop_path=0., act_layer=nn.GELU, norm_layer=nn.LayerNorm, ):
        super().__init__()
        self.window_size = (6, 6)
        if not isinstance(self.window_size, (tuple, list)):
            self.window_size = to_2tuple(window_size)
        self.shift_size = shift_size
        if not isinstance(self.shift_size, (tuple, list)):
            self.shift_size = to_2tuple(shift_size)
        self.bidirectional = bidirectional
        self.norm1 = norm_layer(dim)
        self.attn = InterFrameAttention(
            dim,
            motion_dim,
            num_heads=num_heads, qkv_bias=qkv_bias, qk_scale=qk_scale,
            attn_drop=attn_drop, proj_drop=drop)
        self.drop_path = DropPath(drop_path) if drop_path > 0. else nn.Identity()
        self.norm2 = norm_layer(dim)  # xiugai dim
        mlp_hidden_dim = int(dim * mlp_ratio)
        self.mlp = Mlp(in_features=dim, hidden_features=mlp_hidden_dim, act_layer=act_layer, drop=drop)
        self.apply(self._init_weights)
        self.cor = {}

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if isinstance(m, nn.Linear) and m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)
        elif isinstance(m, nn.Conv2d):
            fan_out = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
            fan_out //= m.groups
            m.weight.data.normal_(0, math.sqrt(2.0 / fan_out))
            if m.bias is not None:
                m.bias.data.zero_()

    def get_cor(self, shape, device):
        k = (str(shape), str(device))
        if k not in self.cor:
            tenHorizontal = torch.linspace(-1.0, 1.0, shape[2], device=device).view(
                1, 1, 1, shape[2]).expand(shape[0], -1, shape[1], -1).permute(0, 2, 3, 1)
            tenVertical = torch.linspace(-1.0, 1.0, shape[1], device=device).view(
                1, 1, shape[1], 1).expand(shape[0], -1, -1, shape[2]).permute(0, 2, 3, 1)
            self.cor[k] = torch.cat([tenHorizontal, tenVertical], -1).to(device)
        return self.cor[k]

    def forward(self, x, H, W, B):
        x = x.contiguous().permute(0, 2, 3, 1).view(2 * B, H, W, -1)  # torch.Size([36, 72, 72, 256])   test torch.Size([2, 72, 72, 256])
        cor = self.get_cor((x.shape[0], H, W), x.device)  # torch.Size([36, 72, 72, 2]) test torch.Size([2, 72, 72, 2])
        x_pad, mask = pad_if_needed(x, x.size(), self.window_size)  # window_size  7 加了padding才能让7整除
        cor_pad, _ = pad_if_needed(cor, cor.size(), self.window_size)
        if self.shift_size[0] or self.shift_size[1]:
            _, H_p, W_p, C = x_pad.shape
            x_pad = torch.roll(x_pad, shifts=(-self.shift_size[0], -self.shift_size[1]), dims=(1, 2))
            cor_pad = torch.roll(cor_pad, shifts=(-self.shift_size[0], -self.shift_size[1]), dims=(1, 2))

            if hasattr(self, 'HW') and self.HW.item() == H_p * W_p:
                shift_mask = self.attn_mask
            else:
                shift_mask = torch.zeros((1, H_p, W_p, 1))  # 1 H W 1
                h_slices = (slice(0, -self.window_size[0]),
                            slice(-self.window_size[0], -self.shift_size[0]),
                            slice(-self.shift_size[0], None))
                w_slices = (slice(0, -self.window_size[1]),
                            slice(-self.window_size[1], -self.shift_size[1]),
                            slice(-self.shift_size[1], None))
                cnt = 0
                for h in h_slices:
                    for w in w_slices:
                        shift_mask[:, h, w, :] = cnt
                        cnt += 1

                mask_windows = window_partition(shift_mask, self.window_size).squeeze(-1)
                shift_mask = mask_windows.unsqueeze(1) - mask_windows.unsqueeze(2)
                shift_mask = shift_mask.masked_fill(shift_mask != 0,
                                                    float(-100.0)).masked_fill(shift_mask == 0,
                                                                               float(0.0))

                if mask is not None:
                    shift_mask = shift_mask.masked_fill(mask != 0,
                                                        float(-100.0))
                #self.register_buffer("attn_mask", shift_mask)
                #self.register_buffer("HW", torch.Tensor([H_p * W_p]))
        else:
            shift_mask = mask

        if shift_mask is not None:
            shift_mask = shift_mask.to(x_pad.device)

        _, Hw, Ww, C = x_pad.shape#torch.Size([36, 72, 72, 256])
        x_win = window_partition(x_pad, self.window_size)#torch.Size([5184, 36, 256])
        

        nwB = x_win.shape[0]
        x_norm = self.norm1(x_win)#torch.Size([5184, 36, 256])
        cor_win = window_partition(cor_pad, self.window_size)[:nwB // 2]
        # x_reverse = torch.cat(
        #     [x_norm[nwB // 2:], x_norm[:nwB // 2]])  # ([144, 49, 128]) #([144, 49, 128]) #调换0通道的前144调到后144
        # x_motion = self.attn(x_norm, x_reverse, cor_win, H, W,
        #                                    shift_mask)  # torch.Size([288, 49, 128]) #x_reverse  #cor_win[288, 49, 2]) H60 W107 shift_mask torch.Size([144, 49, 49])
        x_motion = self.attn(x_norm[:nwB // 2], x_norm[nwB // 2:], cor_win, H, W,
                                            shift_mask)
        # x_norm = x_norm + self.drop_path(x_appearence)

        # x_back = x_norm
        # x_back_win = window_reverse(x_back, self.window_size, Hw, Ww)
        x_motion = window_reverse(x_motion, self.window_size, Hw, Ww)
        if self.shift_size[0] or self.shift_size[1]:
            # x_back_win = torch.roll(x_back_win, shifts=(self.shift_size[0], self.shift_size[1]), dims=(1, 2))
            x_motion = torch.roll(x_motion, shifts=(self.shift_size[0], self.shift_size[1]), dims=(1, 2))
        # x = depad_if_needed(x_back_win, x.size(), self.window_size).view(2*B, H*W, -1)
        x_motion = depad_if_needed(x_motion, cor.size(), self.window_size).view(B, H * W, -1)

        # x_motion = x_motion + self.drop_path(self.mlp(self.norm2(x_motion), H, W))
        #return x.reshape(B, H, W, -1).permute(0, 3, 1, 2).contiguous(), x_motion.reshape(B, H, W, -1).permute(0,3,1,2).contiguous()
        return x_motion.reshape(B, H, W, -1).permute(0,3,1,2).contiguous()


class ResNet(Backbone):
    """ ResNet network module. Allows extracting specific feature blocks."""

    def __init__(self, block, layers, output_layers, num_classes=1000, inplanes=64, dilation_factor=1,
                 frozen_layers=()):
        self.inplanes = inplanes
        super(ResNet, self).__init__(frozen_layers=frozen_layers)
        self.output_layers = output_layers
        self.conv1 = nn.Conv2d(3, inplanes, kernel_size=7, stride=2, padding=3,
                               bias=False)
        self.bn1 = nn.BatchNorm2d(inplanes)
        self.relu = nn.ReLU(inplace=True)

        self.maxpool = nn.MaxPool2d(kernel_size=3, stride=2, padding=1)
        stride = [1 + (dilation_factor < l) for l in (8, 4, 2)]
        self.layer1 = self._make_layer(block, inplanes, layers[0], dilation=max(dilation_factor // 8, 1))
        self.layer2 = self._make_layer(block, inplanes * 2, layers[1], stride=stride[0],
                                       dilation=max(dilation_factor // 4, 1))
        self.layer3 = self._make_layer(block, inplanes * 4, layers[2], stride=stride[1],
                                       dilation=max(dilation_factor // 2, 1))
        self.layer4 = self._make_layer(block, inplanes * 8, layers[3], stride=stride[2], dilation=dilation_factor)

        out_feature_strides = {'conv1': 4, 'layer1': 4, 'layer2': 4 * stride[0], 'layer3': 4 * stride[0] * stride[1],
                               'layer4': 4 * stride[0] * stride[1] * stride[2]}

        # TODO better way?
        if isinstance(self.layer1[0], BasicBlock):
            out_feature_channels = {'conv1': inplanes, 'layer1': inplanes, 'layer2': inplanes * 2,
                                    'layer3': inplanes * 4,
                                    'layer4': inplanes * 8}
        elif isinstance(self.layer1[0], Bottleneck):
            base_num_channels = 4 * inplanes
            out_feature_channels = {'conv1': inplanes, 'layer1': base_num_channels, 'layer2': base_num_channels * 2,
                                    'layer3': base_num_channels * 4, 'layer4': base_num_channels * 8}
        else:
            raise Exception('block not supported')

        self._out_feature_strides = out_feature_strides
        self._out_feature_channels = out_feature_channels

        # self.avgpool = nn.AvgPool2d(7, stride=1)
        self.avgpool = nn.AdaptiveAvgPool2d((1, 1))
        self.fc = nn.Linear(inplanes * 8 * block.expansion, num_classes)
        # self.down = nn.Conv2d(in_channels=1024, out_channels=256, kernel_size=1, stride=1, padding=0)
        window_sizes = [6, 6]
        num_heads = [2, 4]
        mlp_ratios = [4, 4]
        self.motionblock = nn.ModuleList([MotionFormerBlock(
            dim=256, motion_dim=64, num_heads=num_heads[0], window_size=window_sizes[0],
            shift_size=0 if (j % 2) == 0 else window_sizes[0] // 2,
            mlp_ratio=mlp_ratios[0], qkv_bias=True, qk_scale=None,
            drop=0.0, attn_drop=0.0, drop_path=0.0, norm_layer=nn.LayerNorm)
            for j in range(2)])
        # self.motionblock2=MotionFormerBlock(dim=256,motion_dim=256,num_heads=4)
        # self.down_dim = nn.Conv2d(in_channels=256, out_channels=128, kernel_size=1, stride=1, padding=0)
        self.motionblock3 = nn.ModuleList([MotionFormerBlock(
            dim=512, motion_dim=128, num_heads=num_heads[0], window_size=window_sizes[0],
            shift_size=0 if (j % 2) == 0 else window_sizes[0] // 2,
            mlp_ratio=mlp_ratios[0], qkv_bias=True, qk_scale=None,
            drop=0.0, attn_drop=0.0, drop_path=0.0, norm_layer=nn.LayerNorm)
            for j in range(2)])
        self.down = nn.Conv2d(in_channels=384, out_channels=1024, kernel_size=1, stride=1, padding=0)
        # self.down_dim3 = nn.Conv2d(in_channels=512, out_channels=256, kernel_size=1, stride=1, padding=0)
        # self.motionblock4=MotionFormerBlock(dim=1024,motion_dim=256,num_heads=4)
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
            if isinstance(m, nn.Linear):
                trunc_normal_(m.weight, std=.02)
                if isinstance(m, nn.Linear) and m.bias is not None:
                    nn.init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()
        self.history_motion=None
        self.tempral_fuse=Transformertime(256,8,1,1,384,0.1)
        self.down2 = nn.Conv2d(in_channels=1024, out_channels=256, kernel_size=1, stride=1, padding=0)
        self.up3 = nn.Conv2d(in_channels=256, out_channels=1024, kernel_size=1, stride=1, padding=0)
    def out_feature_strides(self, layer=None):
        if layer is None:
            return self._out_feature_strides
        else:
            return self._out_feature_strides[layer]

    def out_feature_channels(self, layer=None):
        if layer is None:
            return self._out_feature_channels
        else:
            return self._out_feature_channels[layer]

    def _make_layer(self, block, planes, blocks, stride=1, dilation=1):
        downsample = None
        if stride != 1 or self.inplanes != planes * block.expansion:
            downsample = nn.Sequential(
                nn.Conv2d(self.inplanes, planes * block.expansion,
                          kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(planes * block.expansion),
            )

        layers = []
        layers.append(block(self.inplanes, planes, stride, downsample, dilation=dilation))
        self.inplanes = planes * block.expansion
        for i in range(1, blocks):
            layers.append(block(self.inplanes, planes))

        return nn.Sequential(*layers)

    def _add_output_and_check(self, name, x, outputs, output_layers):
        if name in output_layers:
            outputs[name] = x
        return len(output_layers) == len(outputs)

    def forward(self, x, x_l, output_layers=None):
        # Forward pass with input x. The output_layers specify the feature blocks which must be returned
        outputs = OrderedDict()
        # x=18,3,288,288
        if output_layers is None:
            output_layers = self.output_layers
        B = x.shape[0]  # 18
        # x = torch.cat([x, x_l], 0)

        x = self.conv1(x)
        x = self.bn1(x)
        x = self.relu(x)  # e([18, 64, 144, 144])

        x_l = self.conv1(x_l)
        x_l = self.bn1(x_l)
        x_l = self.relu(x_l)  # e([18, 64, 144, 144])
        # x1 = torch.cat([x, x_l], 0)  # 36,64,144,144
        # x=x1[:x1.shape[0]//2,:,:,:].contiguous()
        # x1_motion = x1_motion[:x1_motion.shape[0] // 2, :, :, :]
        # x1_motion = nn.functional.interpolate(x1_motion, scale_factor=18 / x1_motion.shape[2], mode='bilinear',
        #                                       align_corners=False)
        # xs.append[x1]
        if self._add_output_and_check('conv1', x, outputs, output_layers):  # e([18, 64, 144, 144])
            return outputs
        motion_features = []
        x = self.maxpool(x)  # torch.Size([18, 64, 72, 72])

        x = self.layer1(x)  # torch.Size([18, 256, 72, 72])

        x_l = self.maxpool(x_l)  # torch.Size([18, 64, 72, 72])

        x_l = self.layer1(x_l)  # torch.Size([18, 256, 72, 72])
        x2 = torch.cat([x, x_l], 0)
        # x2 = self.down_dim(x2)#torch.Size([18, 128, 72, 72])
        for blk in self.motionblock:
            x2_motion = blk(x2, x2.shape[2], x2.shape[3], B)
            x2_motion = nn.functional.interpolate(x2_motion, scale_factor=18 / x2_motion.shape[2], mode='bilinear',
                                                  align_corners=False)
            motion_features.append(x2_motion) #([36, 64, 18, 18])
            # motion_features[i].append()
        # x2_motion = torch.cat([motion_features[0], motion_features[1]], 1)
        # x2_motion = x2_motion[:x2_motion.shape[0] // 2, :, :, :]
        # x2_motion = nn.functional.interpolate(x2_motion, scale_factor=18 / x2_motion.shape[2], mode='bilinear',
        #                                       align_corners=False)  # torch.Size([1, 128, 18, 18])
        if self._add_output_and_check('layer1', x, outputs, output_layers):
            return outputs  # torch.Size([18, 256, 72, 72])

        x = self.layer2(x)  # [18, 512, 36, 36])/36]) torch.Size([36, 512, 36, 36])
        x_l = self.layer2(x_l)
        x3 = torch.cat([x, x_l], 0)
        # x3 = self.down_dim3(x3)#[18, 256, 36, 36])
        for blk in self.motionblock3:
            x3_motion = blk(x3, x3.shape[2], x3.shape[3], B)
            x3_motion = nn.functional.interpolate(x3_motion, scale_factor=18 / x3_motion.shape[2], mode='bilinear',
                                                  align_corners=False)  # torch.Size([1, 256, 36, 36])
            motion_features.append(x3_motion)
        # x3_motion = torch.cat([motion_features[2], motion_features[3]], 1)
        # x3_motion = x3_motion[:x3_motion.shape[0] // 2, :, :, :]
        # x3_motion = nn.functional.interpolate(x3_motion, scale_factor=18 / x3_motion.shape[2], mode='bilinear',
        #                                       align_corners=False)  # torch.Size([1, 256, 36, 36])
        # x3, x3_motion = self.motionblock3(x3, x3.shape[2], x3.shape[3], B)
        # x=x3[:x3.shape[0]//2,:,:,:].contiguous()
        # x3_motion = x3_motion[:x3_motion.shape[0] // 2, :, :, :]
        # x3_motion = nn.functional.interpolate(x3_motion, scale_factor=18 / x3_motion.shape[2], mode='bilinear',
        #                                       align_corners=False)
        # x_motion_all = torch.cat([x, x_l], 0)
        if self._add_output_and_check('layer2', x, outputs, output_layers):
            return outputs  # [18, 512, 36, 36])

        x = self.layer3(x)  # torch.Size([18, 1024, 18, 18])
        x_l = self.layer3(x_l)
        # x4 = torch.cat([x, x_l], 0)
        # xs.append[x4]
        # x4, x4_motion = self.motionblock4(x4, x4.shape[2], x4.shape[3], B)
        # # x=x4[:x4.shape[0]//2,:,:,:].contiguous()
        # x4_motion = x4_motion[:x4_motion.shape[0] // 2, :, :, :]
        # x4_motion = nn.functional.interpolate(x4_motion, scale_factor=18 / x4_motion.shape[2], mode='bilinear',
        #                                       align_corners=False)
        x_motion_all = motion_features[0]
        for i in range(1, len(motion_features)):
            x_motion_all = torch.cat([motion_features[i], x_motion_all], dim=1)  # 384
        x_motion_all = self.down(x_motion_all)
        #x_motion_all = x_motion_all
        x_motion_all=self.down2(x_motion_all)
        if(self.history_motion==None):
            self.history_motion=x_motion_all
            #history_motion=self.down2(self.history_motion)
        elif(self.history_motion.shape!=x_motion_all.shape):
            self.history_motion=x_motion_all
        else:
            history_motion=self.history_motion
        #torch.Size([18, 1024, 18, 18])
        history_motion=self.history_motion
        try:
            x_motion_all=self.tempral_fuse(x_motion_all,history_motion)
        except:
            print(x_motion_all.shape)
            print(history_motion.shape)
        self.history_motion=x_motion_all

        x_motion_all=self.up3(x_motion_all)
        x = x + x_motion_all
        if self._add_output_and_check('layer3', x, outputs, output_layers):
            # return outputs,x_motion_all#torch.Size([18, 1024, 18, 18])
            return outputs  #torch.Size([36, 1024, 18, 18])
        x = self.layer4(x)
        #x_l = self.layer4(x_l)
        if self._add_output_and_check('layer4', x, outputs, output_layers):
            return outputs

        x = self.avgpool(x)
        x = x.view(x.size(0), -1)
        x = self.fc(x)

        if self._add_output_and_check('fc', x, outputs, output_layers):
            return outputs

        if len(output_layers) == 1 and output_layers[0] == 'default':
            return x

        raise ValueError('output_layer is wrong.')


def resnet_baby(output_layers=None, pretrained=False, inplanes=16, **kwargs):
    """Constructs a ResNet-18 model.
    """

    if output_layers is None:
        output_layers = ['default']
    else:
        for l in output_layers:
            if l not in ['conv1', 'layer1', 'layer2', 'layer3', 'layer4', 'fc']:
                raise ValueError('Unknown layer: {}'.format(l))

    model = ResNet(BasicBlock, [2, 2, 2, 2], output_layers, inplanes=inplanes, **kwargs)

    if pretrained:
        raise NotImplementedError
    return model


def resnet18(output_layers=None, pretrained=False, **kwargs):
    """Constructs a ResNet-18 model.
    """

    if output_layers is None:
        output_layers = ['default']
    else:
        for l in output_layers:
            if l not in ['conv1', 'layer1', 'layer2', 'layer3', 'layer4', 'fc']:
                raise ValueError('Unknown layer: {}'.format(l))

    model = ResNet(BasicBlock, [2, 2, 2, 2], output_layers, **kwargs)

    if pretrained:
        model.load_state_dict(model_zoo.load_url(model_urls['resnet18']))
    return model


def resnet50(output_layers=None, pretrained=False, **kwargs):
    """Constructs a ResNet-50 model.
    """

    if output_layers is None:
        output_layers = ['default']
    else:
        for l in output_layers:
            if l not in ['conv1', 'layer1', 'layer2', 'layer3', 'layer4', 'fc']:
                raise ValueError('Unknown layer: {}'.format(l))

    model = ResNet(Bottleneck, [3, 4, 6, 3], output_layers, **kwargs)
    if pretrained:
        model.load_state_dict(model_zoo.load_url(model_urls['resnet50']), strict=False)  # 修改
    return model


def resnet101(output_layers=None, pretrained=False, **kwargs):
    """Constructs a ResNet-101 model.
    """
    if output_layers is None:
        output_layers = ['default']
    else:
        for l in output_layers:
            if l not in ['conv1', 'layer1', 'layer2', 'layer3', 'layer4', 'fc']:
                raise ValueError('Unknown layer: {}'.format(l))

    model = ResNet(Bottleneck, [3, 4, 23, 3], output_layers, **kwargs)
    if pretrained:
        model.load_state_dict(model_zoo.load_url(model_urls['resnet101']))
    return model


def window_partition(x, window_size):
    B, H, W, C = x.shape
    x = x.view(B, H // window_size[0], window_size[0], W // window_size[1], window_size[1], C)
    windows = (
        x.permute(0, 1, 3, 2, 4, 5).contiguous().view(-1, window_size[0] * window_size[1], C)
    )
    return windows


def window_reverse(windows, window_size, H, W):
    nwB, N, C = windows.shape
    windows = windows.view(-1, window_size[0], window_size[1], C)
    B = int(nwB / (H * W / window_size[0] / window_size[1]))
    x = windows.view(
        B, H // window_size[0], W // window_size[1], window_size[0], window_size[1], -1
    )
    x = x.permute(0, 1, 3, 2, 4, 5).contiguous().view(B, H, W, -1)
    return x


def pad_if_needed(x, size, window_size):
    n, h, w, c = size
    pad_h = math.ceil(h / window_size[0]) * window_size[0] - h
    pad_w = math.ceil(w / window_size[1]) * window_size[1] - w
    if pad_h > 0 or pad_w > 0:  # center-pad the feature on H and W axes
        img_mask = torch.zeros((1, h + pad_h, w + pad_w, 1))  # 1 H W 1
        h_slices = (
            slice(0, pad_h // 2),
            slice(pad_h // 2, h + pad_h // 2),
            slice(h + pad_h // 2, None),
        )
        w_slices = (
            slice(0, pad_w // 2),
            slice(pad_w // 2, w + pad_w // 2),
            slice(w + pad_w // 2, None),
        )
        cnt = 0
        for h in h_slices:
            for w in w_slices:
                img_mask[:, h, w, :] = cnt
                cnt += 1

        mask_windows = window_partition(
            img_mask, window_size
        )  # nW, window_size*window_size, 1
        mask_windows = mask_windows.squeeze(-1)
        attn_mask = mask_windows.unsqueeze(1) - mask_windows.unsqueeze(2)
        attn_mask = attn_mask.masked_fill(
            attn_mask != 0, float(-100.0)
        ).masked_fill(attn_mask == 0, float(0.0))
        return nn.functional.pad(
            x,
            (0, 0, pad_w // 2, pad_w - pad_w // 2, pad_h // 2, pad_h - pad_h // 2),
        ), attn_mask
    return x, None


def depad_if_needed(x, size, window_size):
    n, h, w, c = size
    pad_h = math.ceil(h / window_size[0]) * window_size[0] - h
    pad_w = math.ceil(w / window_size[1]) * window_size[1] - w
    if pad_h > 0 or pad_w > 0:  # remove the center-padding on feature
        return x[:, pad_h // 2: pad_h // 2 + h, pad_w // 2: pad_w // 2 + w, :].contiguous()
    return x


class DWConv(nn.Module):
    def __init__(self, dim):
        super(DWConv, self).__init__()
        self.dwconv = nn.Conv2d(dim, dim, 3, 1, 1, bias=True, groups=dim)

    def forward(self, x, H, W):
        B, N, C = x.shape
        x = x.transpose(1, 2).reshape(-1, C, H, W)
        x = self.dwconv(x)
        x = x.reshape(2, C, -1).transpose(1, 2)

        return x



###########################################################################
import copy
from typing import Optional, Any

import torch
from torch import nn,Tensor
import torch.nn.functional as F
from torch.nn import Module
from torch.nn import MultiheadAttention
from torch.nn import ModuleList
from torch.nn.init import xavier_uniform_
from torch.nn import Dropout

class TIF(nn.Module):

    def __init__(self, in_dim):
        super(TIF, self).__init__()
        self.chanel_in = in_dim
        self.conv1=nn.Sequential(
                nn.ConvTranspose2d(in_dim*2, in_dim,  kernel_size=1, stride=1),
                )
        self.conv2=nn.Sequential(
                nn.Conv2d(in_dim, in_dim,  kernel_size=3, stride=3),
                nn.BatchNorm2d(in_dim),
                nn.ReLU(inplace=True),
                )
        self.avg_pool = nn.AdaptiveAvgPool2d(1)
        self.linear1=nn.Conv2d(in_dim, in_dim // 6, 1, bias=False)
        self.linear2=nn.Conv2d(in_dim // 6, in_dim, 1, bias=False)
        self.gamma = nn.Parameter(torch.zeros(1))
        self.activation=nn.ReLU(inplace=True)
        self.dropout=nn.Dropout()
    def forward(self, x,y):
        ww=self.linear2(self.dropout(self.activation(self.linear1(self.avg_pool(self.conv2(y))))))
        weight=self.conv1(torch.cat((x,y),1))*ww
        
        
        return x+self.gamma*weight*x



class Transformertime(Module):


    def __init__(self, d_model: int = 1024, nhead: int = 6, num_encoder_layers: int = 1,
                 num_decoder_layers: int = 1, dim_feedforward: int = 384, dropout: float = 0.1,
                 activation: str = "relu", custom_encoder: Optional[Any] = None, custom_decoder: Optional[Any] = None) -> None:
        super(Transformertime, self).__init__()

        if custom_encoder is not None:
            self.encoder = custom_encoder
        else:
            encoder_layer_ = TransformerEncoderLayer2(d_model, nhead, dim_feedforward, dropout, activation)
            encoder_norm_ = nn.LayerNorm(d_model)
            self.encoder2 = TransformerEncoder2(encoder_layer_, num_encoder_layers, encoder_norm_)

        # if custom_decoder is not None:
        #     self.decoder = custom_decoder
        # else:
        #     decoder_layer = TransformerDecoderLayer(d_model, nhead, dim_feedforward, dropout, activation)
        #     decoder_norm = nn.LayerNorm(d_model)
        #     self.decoder = TransformerDecoder(decoder_layer, num_decoder_layers, decoder_norm)

        self._reset_parameters()

        self.d_model = d_model
        self.nhead = nhead

    # def forward(self, src: Tensor, srcc: Tensor,tgt: Tensor, src_mask: Optional[Tensor] = None, tgt_mask: Optional[Tensor] = None,
    #             memory_mask: Optional[Tensor] = None, src_key_padding_mask: Optional[Tensor] = None,
    #             tgt_key_padding_mask: Optional[Tensor] = None, memory_key_padding_mask: Optional[Tensor] = None) -> Tensor:
    def forward(self, src_: Tensor, srcc_: Tensor, src_mask: Optional[Tensor] = None,
                src_key_padding_mask: Optional[Tensor] = None) -> Tensor: 
        # if src.size(1) != tgt.size(1):
        #     raise RuntimeError("the batch number of src and tgt must be equal")

        # if src.size(2) != self.d_model or tgt.size(2) != self.d_model:
        #     raise RuntimeError("the feature number of src and tgt must be equal to d_model")

        memory2 = self.encoder2(src_,srcc_, mask=src_mask, src_key_padding_mask=src_key_padding_mask)
        # output = self.decoder(tgt,srcc, memory, tgt_mask=tgt_mask, memory_mask=memory_mask,
        #                       tgt_key_padding_mask=tgt_key_padding_mask,
        #                       memory_key_padding_mask=memory_key_padding_mask)
        #return memory,output
        return memory2.permute(0,2,1).reshape(src_.shape)
        #return memory2
    def generate_square_subsequent_mask(self, sz: int) -> Tensor:
        r"""Generate a square mask for the sequence. The masked positions are filled with float('-inf').
            Unmasked positions are filled with float(0.0).
        """
        mask = (torch.triu(torch.ones(sz, sz)) == 1).transpose(0, 1)
        mask = mask.float().masked_fill(mask == 0, float('-inf')).masked_fill(mask == 1, float(0.0))
        return mask

    def _reset_parameters(self):
        r"""Initiate parameters in the transformer model."""

        for p in self.parameters():
            if p.dim() > 1:
                xavier_uniform_(p)


class TransformerEncoder2(Module):
    r"""TransformerEncoder is a stack of N encoder layers

    Args:
        encoder_layer: an instance of the TransformerEncoderLayer() class (required).
        num_layers: the number of sub-encoder-layers in the encoder (required).
        norm: the layer normalization component (optional).

    Examples::
        >>> encoder_layer = nn.TransformerEncoderLayer(d_model=512, nhead=8)
        >>> transformer_encoder = nn.TransformerEncoder(encoder_layer, num_layers=6)
        >>> src = torch.rand(10, 32, 512)
        >>> out = transformer_encoder(src)
    """
    __constants__ = ['norm']

    def __init__(self, encoder_layer, num_layers, norm=None):
        super(TransformerEncoder2, self).__init__()
        self.layers = _get_clones(encoder_layer, num_layers)
        self.num_layers = num_layers
        self.norm_2 = norm

    def forward(self, src: Tensor,srcc: Tensor, mask: Optional[Tensor] = None, src_key_padding_mask: Optional[Tensor] = None) -> Tensor:
        r"""Pass the input through the encoder layers in turn.

        Args:
            src: the sequence to the encoder (required).
            mask: the mask for the src sequence (optional).
            src_key_padding_mask: the mask for the src keys per batch (optional).

        Shape:
            see the docs in Transformer class.
        """
        output_ = src

        for mod in self.layers:
            output_ = mod(output_,srcc, src_mask=mask, src_key_padding_mask=src_key_padding_mask)

        # if self.norm_2 is not None:
        #     output_ = self.norm_2(output_)

        return output_


# class TransformerDecoder(Module):
#     r"""TransformerDecoder is a stack of N decoder layers

#     Args:
#         decoder_layer: an instance of the TransformerDecoderLayer() class (required).
#         num_layers: the number of sub-decoder-layers in the decoder (required).
#         norm: the layer normalization component (optional).

#     Examples::
#         >>> decoder_layer = nn.TransformerDecoderLayer(d_model=512, nhead=8)
#         >>> transformer_decoder = nn.TransformerDecoder(decoder_layer, num_layers=6)
#         >>> memory = torch.rand(10, 32, 512)
#         >>> tgt = torch.rand(20, 32, 512)
#         >>> out = transformer_decoder(tgt, memory)
#     """
#     __constants__ = ['norm']

#     def __init__(self, decoder_layer, num_layers, norm=None):
#         super(TransformerDecoder, self).__init__()
#         self.layers = _get_clones(decoder_layer, num_layers)
#         self.num_layers = num_layers
#         self.norm = norm

#     def forward(self, tgt: Tensor, srcc: Tensor, memory: Tensor, tgt_mask: Optional[Tensor] = None,
#                 memory_mask: Optional[Tensor] = None, tgt_key_padding_mask: Optional[Tensor] = None,
#                 memory_key_padding_mask: Optional[Tensor] = None) -> Tensor:
#         r"""Pass the inputs (and mask) through the decoder layer in turn.

#         Args:
#             tgt: the sequence to the decoder (required).
#             memory: the sequence from the last layer of the encoder (required).
#             tgt_mask: the mask for the tgt sequence (optional).
#             memory_mask: the mask for the memory sequence (optional).
#             tgt_key_padding_mask: the mask for the tgt keys per batch (optional).
#             memory_key_padding_mask: the mask for the memory keys per batch (optional).

#         Shape:
#             see the docs in Transformer class.
#         """
#         output = tgt

#         for mod in self.layers:
#             output = mod(output, srcc,memory, tgt_mask=tgt_mask,
#                          memory_mask=memory_mask,
#                          tgt_key_padding_mask=tgt_key_padding_mask,
#                          memory_key_padding_mask=memory_key_padding_mask)

#         if self.norm is not None:
#             output = self.norm(output)

#         return output

class TransformerEncoderLayer2(Module):
    r"""TransformerEncoderLayer is made up of self-attn and feedforward network.
    This standard encoder layer is based on the paper "Attention Is All You Need".
    Ashish Vaswani, Noam Shazeer, Niki Parmar, Jakob Uszkoreit, Llion Jones, Aidan N Gomez,
    Lukasz Kaiser, and Illia Polosukhin. 2017. Attention is all you need. In Advances in
    Neural Information Processing Systems, pages 6000-6010. Users may modify or implement
    in a different way during application.

    Args:
        d_model: the number of expected features in the input (required).
        nhead: the number of heads in the multiheadattention models (required).
        dim_feedforward: the dimension of the feedforward network model (default=384).
        dropout: the dropout value (default=0.1).
        activation: the activation function of intermediate layer, relu or gelu (default=relu).

    Examples::
        >>> encoder_layer = nn.TransformerEncoderLayer(d_model=512, nhead=8)
        >>> src = torch.rand(10, 32, 512)
        >>> out = encoder_layer(src)
    """

    def __init__(self, d_model, nhead, dim_feedforward=384, dropout=0.1, activation="relu"):
        super(TransformerEncoderLayer2, self).__init__()
        self.self_attn_1 = MultiheadAttention(d_model, nhead, dropout=dropout)
        #self.self_attn_1 = Attention(d_model, num_heads=nhead, qkv_bias=True, attn_drop=0.1, proj_drop=0.1)
        self.self_attn_2 = MultiheadAttention(d_model, nhead, dropout=dropout)
        self.self_attn_3 = MultiheadAttention(d_model, nhead, dropout=dropout)
        #channel=dim_feedforward//2
        #self.modulation=TIF(channel)
        #self.cross_attn_ = MultiheadAttention(d_model, nhead, dropout=dropout)
        # Implementation of Feedforward model

        self.norm_0 = nn.LayerNorm(d_model)
        self.norm_1 = nn.LayerNorm(d_model)
        self.norm_2 = nn.LayerNorm(d_model)
        self.norm_3 = nn.LayerNorm(d_model)

        self.dropout_1 = Dropout(dropout)
        self.dropout_2 = Dropout(dropout)
        self.dropout_3 = Dropout(dropout)
        self.dropout= Dropout(dropout)
        self.linear1 = nn.Linear(d_model, dim_feedforward)
        self.linear2 = nn.Linear(dim_feedforward, d_model)

        self.activation_ = _get_activation_fn(activation)

    def __setstate__(self, state):
        if 'activation' not in state:
            state['activation'] = F.relu
        super(TransformerEncoderLayer2, self).__setstate__(state)
    ##没加ffn
    def forward(self, src: Tensor,srcc: Tensor, src_mask: Optional[Tensor] = None, src_key_padding_mask: Optional[Tensor] = None) -> Tensor:
        src_=src.flatten(2).permute(0,2,1)
        srcc_=srcc.flatten(2).permute(0,2,1)
        b,s,c=src_.size()
 
        src_1 = self.self_attn_1(srcc_.detach(), src_.detach(), src_.detach(), attn_mask=src_mask,
                                key_padding_mask=src_key_padding_mask)[0]
        srcs_1 = src_ + self.dropout_1(src_1)
        srcs_1 = self.norm_1(srcs_1)
        # src_1 = self.self_attn_1(srcc_,src_)
        # srcs_1 = src_ + self.dropout_1(src_1)
        # srcs_1 = self.norm_1(srcs_1)
        src_2 = self.self_attn_2(srcs_1, srcs_1, srcs_1, attn_mask=src_mask,
                                key_padding_mask=src_key_padding_mask)[0]
        srcs_2 = srcs_1 + self.dropout_2(src_2)
        srcs_2 = self.norm_2(srcs_2)
        
        # src=self.modulation(srcs2.view(b,c,int(s**0.5),int(s**0.5))\
        #                      ,srcs1.contiguous().view(b,c,int(s**0.5),int(s**0.5))).view(b,c,-1).permute(2, 0, 1)
        
        # src2 = self.self_attn3(src, src, src, attn_mask=src_mask,
        #                         key_padding_mask=src_key_padding_mask)[0]
        # srcs1 = src + self.dropout3(src2)
        # srcs1 = self.norm3(srcs1)
    
        return srcs_2
        #return srcs_1
    #加了ffn
    # def forward(self, src: Tensor,srcc: Tensor, src_mask: Optional[Tensor] = None, src_key_padding_mask: Optional[Tensor] = None) -> Tensor:
    #     src_=src.flatten(2).permute(0,2,1)
    #     srcc_=srcc.flatten(2).permute(0,2,1)
    #     b,s,c=src_.size()
 
    #     src_1 = self.self_attn_1(srcc_.detach(), src_.detach(), src_.detach(), attn_mask=src_mask,
    #                             key_padding_mask=src_key_padding_mask)[0]
    #     srcs_1 = src_ + self.dropout_1(src_1)
    #     srcs_1 = self.norm_1(srcs_1)
    #     # src_1 = self.self_attn_1(srcc_,src_)
    #     # srcs_1 = src_ + self.dropout_1(src_1)
    #     # srcs_1 = self.norm_1(srcs_1)
    #     src_2 = self.self_attn_2(srcs_1, srcs_1, srcs_1, attn_mask=src_mask,
    #                             key_padding_mask=src_key_padding_mask)[0]
    #     srcs_2 = srcs_1 + self.dropout_2(src_2)
    #     srcs_2 = self.norm_2(srcs_2)
        
    #     # src=self.modulation(srcs2.view(b,c,int(s**0.5),int(s**0.5))\
    #     #                      ,srcs1.contiguous().view(b,c,int(s**0.5),int(s**0.5))).view(b,c,-1).permute(2, 0, 1)
        
    #     # src2 = self.self_attn3(src, src, src, attn_mask=src_mask,
    #     #                         key_padding_mask=src_key_padding_mask)[0]
    #     # srcs1 = src + self.dropout3(src2)
    #     # srcs1 = self.norm3(srcs1)
    #     src_3 = self.linear2(self.dropout(self.activation(self.linear1(srcs_2))))
    #     srcs_2 = srcs_2 + self.dropout_3(src_3)
    #     srcs_2 = self.norm_3(srcs_2)
    #     return srcs_2
        #return srcs_1

    def forward_test(self, x, s_h, s_w):
        B, N, C = x.shape
        qkv_s = self.qkv(x).reshape(B, N, 3, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        q_s, _, _ = qkv_s.unbind(0)   # make torchscript happy (cannot use tensor as tuple)
        qkv = torch.cat([self.qkv_mem, qkv_s], dim=3)
        _, k, v = qkv.unbind(0)

        attn = (q_s @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)
        x = (attn @ v).transpose(1, 2).reshape(B, s_h*s_w, C)

        x = self.proj(x)
        x = self.proj_drop(x)
        return x

    def set_online(self, x, t_h, t_w):
        B, N, C = x.shape
        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        self.qkv_mem = qkv
        q, k, v = qkv.unbind(0)   # make torchscript happy (cannot use tensor as tuple) [B, num_heads, N, C//num_heads]

        # asymmetric mixed attention
        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)
        x = (attn @ v).transpose(1, 2).reshape(B, N, C)

        x = self.proj(x)
        x = self.proj_drop(x)
        return x
# class TransformerDecoderLayer(Module):
#     r"""TransformerDecoderLayer is made up of self-attn, multi-head-attn and feedforward network.
#     This standard decoder layer is based on the paper "Attention Is All You Need".
#     Ashish Vaswani, Noam Shazeer, Niki Parmar, Jakob Uszkoreit, Llion Jones, Aidan N Gomez,
#     Lukasz Kaiser, and Illia Polosukhin. 2017. Attention is all you need. In Advances in
#     Neural Information Processing Systems, pages 6000-6010. Users may modify or implement
#     in a different way during application.

#     Args:
#         d_model: the number of expected features in the input (required).
#         nhead: the number of heads in the multiheadattention models (required).
#         dim_feedforward: the dimension of the feedforward network model (default=2048).
#         dropout: the dropout value (default=0.1).
#         activation: the activation function of intermediate layer, relu or gelu (default=relu).

#     Examples::
#         >>> decoder_layer = nn.TransformerDecoderLayer(d_model=512, nhead=8)
#         >>> memory = torch.rand(10, 32, 512)
#         >>> tgt = torch.rand(20, 32, 512)
#         >>> out = decoder_layer(tgt, memory)
#     """

#     def __init__(self, d_model, nhead, dim_feedforward=384, dropout=0.1, activation="relu"):
#         super(TransformerDecoderLayer, self).__init__()
#         self.self_attn = MultiheadAttention(d_model, nhead, dropout=dropout)
#         self.multihead_attn1 = MultiheadAttention(d_model, nhead, dropout=dropout)
#         self.multihead_attn2 = MultiheadAttention(d_model, nhead, dropout=dropout)
#         # Implementation of Feedforward model
#         self.linear1 = nn.Linear(d_model, dim_feedforward)
#         self.dropout = Dropout(dropout)
#         self.linear2 = nn.Linear(dim_feedforward, d_model)

#         self.norm1 = nn.LayerNorm(d_model)
#         self.norm2 = nn.LayerNorm(d_model)
#         self.norm3 = nn.LayerNorm(d_model)
#         self.norm4 = nn.LayerNorm(d_model)
#         self.dropout1 = Dropout(dropout)
#         self.dropout2 = Dropout(dropout)
#         self.dropout3 = Dropout(dropout)
#         self.dropout4 = Dropout(dropout)
#         self.activation = _get_activation_fn(activation)

#     def __setstate__(self, state):
#         if 'activation' not in state:
#             state['activation'] = F.relu
#         super(TransformerDecoderLayer, self).__setstate__(state)

#     def forward(self, tgt: Tensor, srcc: Tensor, memory: Tensor, tgt_mask: Optional[Tensor] = None, memory_mask: Optional[Tensor] = None,
#                 tgt_key_padding_mask: Optional[Tensor] = None, memory_key_padding_mask: Optional[Tensor] = None) -> Tensor:
#         r"""Pass the inputs (and mask) through the decoder layer.

#         Args:
#             tgt: the sequence to the decoder layer (required).
#             memory: the sequence from the last layer of the encoder (required).
#             tgt_mask: the mask for the tgt sequence (optional).
#             memory_mask: the mask for the memory sequence (optional).
#             tgt_key_padding_mask: the mask for the tgt keys per batch (optional).
#             memory_key_padding_mask: the mask for the memory keys per batch (optional).

#         Shape:
#             see the docs in Transformer class.
#         """
#         tgt2 = self.self_attn(tgt, tgt, tgt, attn_mask=tgt_mask,
#                               key_padding_mask=tgt_key_padding_mask)[0]
#         tgt = tgt + self.dropout1(tgt2)
#         tgt = self.norm1(tgt)
        
#         tgt12 = self.multihead_attn1(tgt, memory, memory, attn_mask=memory_mask,
#                                    key_padding_mask=memory_key_padding_mask)[0]
        

#         tgt = tgt + self.dropout2(tgt12)
#         tgt = self.norm2(tgt)
        
#         tgt2 = self.linear2(self.dropout(self.activation(self.linear1(tgt))))
#         tgt = tgt + self.dropout4(tgt2)
#         tgt = self.norm4(tgt)
#         return tgt


def _get_clones(module, N):
    return ModuleList([copy.deepcopy(module) for i in range(N)])


def _get_activation_fn(activation):
    if activation == "relu":
        return F.relu
    elif activation == "gelu":
        return F.gelu

    raise RuntimeError("activation should be relu/gelu, not {}".format(activation))
