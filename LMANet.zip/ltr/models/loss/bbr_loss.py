import torch
import torch.nn as nn


class GIoULoss(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, pred, target, weights=None):
        if pred.dim() == 4:
            pred = pred.unsqueeze(0)

        pred = pred.permute(0, 1, 3, 4, 2).reshape(-1, 4) # nf x ns x x 4 x h x w
        target = target.permute(0, 1, 3, 4, 2).reshape(-1, 4) #nf x ns x 4 x h x w

        pred_left = pred[:, 0]
        pred_top = pred[:, 1]
        pred_right = pred[:, 2]
        pred_bottom = pred[:, 3]

        target_left = target[:, 0]
        target_top = target[:, 1]
        target_right = target[:, 2]
        target_bottom = target[:, 3]

        target_area = (target_left + target_right) * \
                      (target_top + target_bottom)
        pred_area = (pred_left + pred_right) * \
                    (pred_top + pred_bottom)

        w_intersect = torch.min(pred_left, target_left) + torch.min(pred_right, target_right)
        g_w_intersect = torch.max(pred_left, target_left) + torch.max(
            pred_right, target_right)
        h_intersect = torch.min(pred_bottom, target_bottom) + torch.min(pred_top, target_top)
        g_h_intersect = torch.max(pred_bottom, target_bottom) + torch.max(pred_top, target_top)
        ac_union = g_w_intersect * g_h_intersect + 1e-7
        area_intersect = w_intersect * h_intersect
        area_union = target_area + pred_area - area_intersect + 1e-7
        ious = (area_intersect) / (area_union)
        gious = ious - (ac_union - area_union) / ac_union

        losses = 1 - gious

        if weights is not None and weights.sum() > 0:
            weights = weights.permute(0, 1, 3, 4, 2).reshape(-1) # nf x ns x x 1 x h x w
            loss_mean = losses[weights>0].mean()
            ious = ious[weights>0]
        else:
            loss_mean = losses.mean()

        return loss_mean, ious

# class Wasserstein_Loss(nn.Module):
#     def __init__(self):
#         super().__init__()

#     def forward(self, pred, target, weights=None,eps=1e-7, constant=12.8):
#         """`Implementation of paper `Enhancing Geometric Factors into
#         Model Learning and Inference for Object Detection and Instance
#         Segmentation <https://arxiv.org/abs/2005.03572>`_.
#         Code is modified from https://github.com/Zzh-tju/CIoU.
#         Args:
#             pred (Tensor): Predicted bboxes of format (x_center, y_center, w, h),
#                 shape (n, 4).
#             target (Tensor): Corresponding gt bboxes, shape (n, 4).
#             eps (float): Eps to avoid log(0).
#         Return:
#             Tensor: Loss tensor.
#         """

#         center1 = pred[:, :2]
#         center2 = target[:, :2]

#         whs = center1[:, :2] - center2[:, :2]

#         center_distance = whs[:, 0] * whs[:, 0] + whs[:, 1] * whs[:, 1] + eps #

#         w1 = pred[:, 2]  + eps
#         h1 = pred[:, 3]  + eps
#         w2 = target[:, 2] + eps
#         h2 = target[:, 3] + eps

#         wh_distance = ((w1 - w2) ** 2 + (h1 - h2) ** 2) / 4

#         wasserstein_2 = center_distance + wh_distance
#         return torch.exp(-torch.sqrt(wasserstein_2) / constant)



#     nwd = wasserstein_loss(pbox, tbox[i]).squeeze()
#     iou_ratio = 0.5
#     lbox += (1 - iou_ratio) * (1.0 - nwd).mean() + iou_ratio * (1.0 - iou).mean()  # iou loss

#     # Objectness
#     iou = (iou.detach() * iou_ratio + nwd.detach() * (1 - iou_ratio)).clamp(0, 1).type(tobj.dtype)
