import importlib
import os
import numpy as np
from collections import OrderedDict
from pytracking.evaluation.environment import env_settings
import time
import cv2 as cv
from pytracking.utils.visdom import Visdom
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from pytracking.utils.plotting import draw_figure, overlay_mask
from pytracking.utils.convert_vot_anno_to_rect import convert_vot_anno_to_rect
from ltr.data.bounding_box_utils import masks_to_bboxes
from pytracking.evaluation.multi_object_wrapper import MultiObjectWrapper
from pathlib import Path
import torch
import pytracking.predict.individual_TF as individual_TF

_tracker_disp_colors = {1: (0, 255, 0), 2: (0, 0, 255), 3: (255, 0, 0),
                        4: (255, 255, 255), 5: (0, 0, 0), 6: (0, 255, 128),
                        7: (123, 123, 123), 8: (255, 128, 0), 9: (128, 0, 255)}


def trackerlist(name: str, parameter_name: str, run_ids = None, display_name: str = None):
    """Generate list of trackers.
    args:
        name: Name of tracking method.
        parameter_name: Name of parameter file.
        run_ids: A single or list of run_ids.
        display_name: Name to be displayed in the result plots.
    """
    if run_ids is None or isinstance(run_ids, int):
        run_ids = [run_ids]
    return [Tracker(name, parameter_name, run_id, display_name) for run_id in run_ids]


class Tracker:
    """Wraps the tracker for evaluation and running purposes.
    args:
        name: Name of tracking method.
        parameter_name: Name of parameter file.
        run_id: The run id.
        display_name: Name to be displayed in the result plots.
    """

    def __init__(self, name: str, parameter_name: str, run_id: int = None, display_name: str = None):
        assert run_id is None or isinstance(run_id, int)

        self.name = name
        self.parameter_name = parameter_name
        self.run_id = run_id
        self.display_name = display_name

        env = env_settings()
        if self.run_id is None:
            self.results_dir = '{}/{}/{}'.format(env.results_path, self.name, self.parameter_name)
            self.segmentation_dir = '{}/{}/{}'.format(env.segmentation_path, self.name, self.parameter_name)
        else:
            self.results_dir = '{}{}/{}_{:03d}'.format(env.results_path, self.name, self.parameter_name, self.run_id)
            #self.results_dir = '{}/{}/{}_{:03d}'.format(env.results_path, self.name, self.parameter_name, self.run_id)
            self.segmentation_dir = '{}/{}/{}_{:03d}'.format(env.segmentation_path, self.name, self.parameter_name, self.run_id)

        tracker_module_abspath = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'tracker', self.name))
        if os.path.isdir(tracker_module_abspath):
            tracker_module = importlib.import_module('pytracking.tracker.{}'.format(self.name))
            self.tracker_class = tracker_module.get_tracker_class()
        else:
            self.tracker_class = None

        self.visdom = None


    def _init_visdom(self, visdom_info, debug):
        visdom_info = {} if visdom_info is None else visdom_info
        self.pause_mode = False
        self.step = False
        if debug > 0 and visdom_info.get('use_visdom', True):
            try:
                self.visdom = Visdom(debug, {'handler': self._visdom_ui_handler, 'win_id': 'Tracking'},
                                     visdom_info=visdom_info)

                # Show help
                help_text = 'You can pause/unpause the tracker by pressing ''space'' with the ''Tracking'' window ' \
                            'selected. During paused mode, you can track for one frame by pressing the right arrow key.' \
                            'To enable/disable plotting of a data block, tick/untick the corresponding entry in ' \
                            'block list.'
                self.visdom.register(help_text, 'text', 1, 'Help')
            except:
                time.sleep(0.5)
                print('!!! WARNING: Visdom could not start, so using matplotlib visualization instead !!!\n'
                      '!!! Start Visdom in a separate terminal window by typing \'visdom\' !!!')

    def _visdom_ui_handler(self, data):
        if data['event_type'] == 'KeyPress':
            if data['key'] == ' ':
                self.pause_mode = not self.pause_mode

            elif data['key'] == 'ArrowRight' and self.pause_mode:
                self.step = True


    def create_tracker(self, params):
        tracker = self.tracker_class(params)
        tracker.visdom = self.visdom
        return tracker

    def run_sequence(self, seq, visualization=None, debug=None, visdom_info=None, multiobj_mode=None):
        """Run tracker on sequence.
        args:
            seq: Sequence to run the tracker on.
            visualization: Set visualization flag (None means default value specified in the parameters).
            debug: Set debug level (None means default value specified in the parameters).
            visdom_info: Visdom info.
            multiobj_mode: Which mode to use for multiple objects.
        """
        params = self.get_parameters()
        visualization_ = visualization

        debug_ = debug
        if debug is None:
            debug_ = getattr(params, 'debug', 0)
        if visualization is None:
            if debug is None:
                visualization_ = getattr(params, 'visualization', False)
            else:
                visualization_ = True if debug else False

        params.visualization = visualization_
        params.debug = debug_

        self._init_visdom(visdom_info, debug_)
        if visualization_ and self.visdom is None:
            self.init_visualization()

        # Get init information
        init_info = seq.init_info()
        is_single_object = not seq.multiobj_mode

        if multiobj_mode is None:
            multiobj_mode = getattr(params, 'multiobj_mode', getattr(self.tracker_class, 'multiobj_mode', 'default'))

        if multiobj_mode == 'default' or is_single_object:
            tracker = self.create_tracker(params)
        elif multiobj_mode == 'parallel':
            tracker = MultiObjectWrapper(self.tracker_class, params, self.visdom)
        else:
            raise ValueError('Unknown multi object mode {}'.format(multiobj_mode))

        output = self._track_sequence_predict(tracker, seq, init_info)
        #output = self._track_sequence(tracker, seq, init_info)
        return output
    def correct(self,res1,track_id):
        if(len(track_id)-10>0):
            x=res1[0]
            y=res1[1]
            w=res1[2]
            h=res1[3]
            x_center=x+w/2 #260
            y_center=y+h/2 #162
            x_past_center=track_id[len(track_id)-1][0]
            y_past_center=track_id[len(track_id)-1][1]
            x_0past_center=track_id[len(track_id)-9][0]
            y_0past_center=track_id[len(track_id)-9][1]
            dv=np.sqrt(np.power(x_past_center-x_0past_center,2)+np.power(y_past_center-y_0past_center,2))/8

            x1_past_center=track_id[len(track_id)-2][0]
            y1_past_center=track_id[len(track_id)-2][1]
            dd=np.sqrt(np.power(x_center-x_past_center,2)+np.power(y_center-y_past_center,2))
            #dd2=np.sqrt(np.power(x1_past_center-x_past_center,2)+np.power(y1_past_center-y_past_center,2))
            if(dd>dv*6):
                return True
        else:
            return False
    def _track_sequence_predict(self, tracker, seq, init_info):
        # Define outputs
        # Each field in output is a list containing tracker prediction for each frame.

        # In case of single object tracking mode:
        # target_bbox[i] is the predicted bounding box for frame i
        # time[i] is the processing time for frame i
        # segmentation[i] is the segmentation mask for frame i (numpy array)

        # In case of multi object tracking mode:
        # target_bbox[i] is an OrderedDict, where target_bbox[i][obj_id] is the predicted box for target obj_id in
        # frame i
        # time[i] is either the processing time for frame i, or an OrderedDict containing processing times for each
        # object in frame i
        # segmentation[i] is the multi-label segmentation mask for frame i (numpy array)

        output = {'target_bbox': [],
                  'time': [],
                  'segmentation': [],
                  'object_presence_score': []}

        def _store_outputs(tracker_out: dict, defaults=None):
            defaults = {} if defaults is None else defaults
            for key in output.keys():
                val = tracker_out.get(key, defaults.get(key, None))
                if key in tracker_out or val is not None:
                    output[key].append(val)

        # Initialize
        image = self._read_image(seq.frames[0])
        if tracker.params.visualization and self.visdom is None:
            self.visualize(image, init_info.get('init_bbox'))

        start_time = time.time()
        out = tracker.initialize(image, init_info)
        if out is None:
            out = {}

        prev_output = OrderedDict(out)
        
        init_default = {'target_bbox': init_info.get('init_bbox'),
                        'time': time.time() - start_time,
                        'segmentation': init_info.get('init_mask'),
                        'object_presence_score': 1.}

        _store_outputs(out, init_default)
        track_id={}
        bbox_size = init_default['target_bbox']
        center_x = bbox_size[0] + 0.5 * bbox_size[2]
        center_y = bbox_size[1] + 0.5 * bbox_size[3]
        track_id[0]=[center_x,center_y]
        # dx_track={}
        # dx_track[0]=[0,0]
        #预测模块

        # model = individual_TF.IndividualTF(2, 3, 3, N=6,
        #                             d_model=512, d_ff=2048, h=8, 
        #                             mean=[0, 0], std=[0, 0])
        model = individual_TF.IndividualTF(2, 3, 3, N=6,
                            d_model=512, d_ff=2048, h=8, 
                            mean=[0, 0], std=[0, 0])
        #model.load_state_dict(torch.load(f'/home/lcl_d/zhaoxingle/pytracking_tomp/Trajectory-predict/models/Individual/satsot_3_1_0_200/00199.pth'))
        #model.load_state_dict(torch.load(f'/home/lcl_d/zhaoxingle/pytracking_tomp/Trajectory-predict/models/Individual/LaTOT_8_2_?/00099.pth'))
        #model.load_state_dict(torch.load(f'/home/lcl_d/zhaoxingle/pytracking_tomp/Trajectory-predict/models/Individual/satsot_3_1_0_200/00199.pth'))
        #model.load_state_dict(torch.load(f'/home/lcl_d/zhaoxingle/pytracking_tomp/Trajectory-predict/models/Individual/LaTOT_3_1_0_200/00144.pth'))
        #model.load_state_dict(torch.load(f'/home/lcl_d/zhaoxingle/pytracking_tomp/Trajectory-predict/models/Individual/zara1/00032.pth'))0.75
        #model.load_state_dict(torch.load(f'/home/lcl_d/zhaoxingle/pytracking_tomp/Trajectory-predict/models/Individual/zara1/00043.pth'))0.8
        #model.load_state_dict(torch.load(f'/home/lcl_d/zhaoxingle/pytracking_tomp/Trajectory-predict/models/Individual/zara1/00060.pth'))#bucuo peishang 49
        #model.load_state_dict(torch.load(f'/home/lcl_d/zhaoxingle/pytracking_tomp/Trajectory-predict/models/Individual/zara1/00070.pth'))
        #model.load_state_dict(torch.load(f'/home/lcl_d/zhaoxingle/pytracking_tomp/Trajectory-predict/models/Individual/LaTOT_dx_3_1_0_200/00199.pth'))
        #model.load_state_dict(torch.load(f'/home/lcl_d/zhaoxingle/pytracking_tomp/Trajectory-predict/models/Individual/zara2/00029.pth'))
        #model.load_state_dict(torch.load(f'/home/lcl_d/zhaoxingle/pytracking_tomp/Trajectory-predict/models/Individual/zara2/00864.pth'))
        model.load_state_dict(torch.load(f'/home/lcl_d/zhaoxingle/pytracking_tomp/Trajectory-predict/models/Individual/zara5/00300.pth'))
        #model.load_state_dict(torch.load(f'/home/lcl_d/zhaoxingle/pytracking_tomp/Trajectory-predict/models/Individual/zara5/00499.pth'))
        
        count = 0
        flag_0 = False
        flag_1 = False
        for frame_num, frame_path in enumerate(seq.frames[1:], start=1):#从第一帧开始
            while True:
                if not self.pause_mode:
                    break
                elif self.step:
                    self.step = False
                    break
                else:
                    time.sleep(0.1)

            image = self._read_image(frame_path)

            lst_url = frame_path.split('/')
            lst_url.pop(-1)
            pre = '/'.join(lst_url)
            jpg_name=frame_path.split('/')[-1]
            
            # if(seq.dataset=='SV248A10'):
            #     frame_path_l=os.path.join(pre,'{:06}.tiff'.format(int(jpg_name.split('.')[-2])-1))
            # else:
            #     a=int(jpg_name.split('.')[-2])
            #     frame_path_l=os.path.join(pre,'{:04}.jpg'.format(a-1)) 
            
            if(seq.dataset=='SV248A10'):
                frame_path_l=os.path.join(pre,'{:06}.tiff'.format(int(jpg_name.split('.')[-2])-1))
            else:
                a=int(jpg_name.split('.')[-2])
                frame_path_l=os.path.join(pre,'{:04}.jpg'.format(a-1)) #sot

            image_l = self._read_image(frame_path_l)
            info = seq.frame_info(frame_num)
            info['previous_output'] = prev_output
            prev_output['target_bbox']=init_default['target_bbox']#jiade
      
            # if('shift' in prev_output.keys()):
            #      info['shift']=prev_output['shift']
            #info['guiji']=(init_default['target'])

            # if(frame_num == 1):
            #     bbox_size = init_default['target_bbox']
            #     center_x = bbox_size[0] + 0.5 * bbox_size[2]
            #     center_y = bbox_size[1] + 0.5 * bbox_size[3]
            #     inp_np = [[center_x, center_y],
            #                 [center_x, center_y],
            #                 [center_x, center_y]] 
            # if(frame_num ==2):
            #         inp_np_new = [[center_x_g - center_x, center_y_g - center_y]]
            #         inp_np_new.extend(inp_list)
            #         inp_np_new.extend(inp_list)
            #         inp_np = inp_np_new
            # if(frame_num == 3):
            #         inp_np = inp_np[:,0:2]
            #         inp_np = inp_np.squeeze(0)
            #         inp_np = inp_np.tolist()
            #         inp_np.extend(inp_list)
            # if(frame_num >3):
            #         inp_np = inp_np[:,1:]
            #         inp_np = inp_np.squeeze(0)
            #         inp_np = inp_np.tolist()
            #         inp_np.extend(inp_list)
            #         inp_np = np.array(inp_np)
            # inp_np = torch.tensor(inp_np)
            # inp_np = inp_np.unsqueeze(0)
            # inp_speed = np.concatenate((np.zeros((inp_np.shape[0],1,2)),inp_np[:,1:,0:2] - inp_np[:, :-1, 0:2]),1)
            # inp_norm=np.concatenate((inp_np,inp_speed),2)
            # inp = inp_norm[:, 1:, 2:4]
            # src_att = torch.ones((inp.shape[0], 1, inp.shape[1]))
            # start_of_seq = torch.Tensor([0, 0, 1]).unsqueeze(0).unsqueeze(1).repeat(inp.shape[0], 1, 1)
            # dec_inp = start_of_seq
            # trg_att =[[True]]
            # inp = np.float32(inp)
            # dec_inp = np.float32(dec_inp)
            # src_att = np.float32(src_att)
            # inp = torch.tensor(inp)
            # inp_norm = torch.tensor(inp_norm)
            # dec_inp = torch.tensor(dec_inp)
            # src_att = torch.tensor(src_att)
            # trg_att = torch.tensor(trg_att)
            # trg_att = trg_att.unsqueeze(0)              
            # result = model(inp, dec_inp, src_att, trg_att)
            # dec_inp = torch.cat((dec_inp, result[:, -1:, :]),  1)
            # pred = dec_inp[:, 1:, 0:2] + inp_norm[:, -1:, 0:2]

            # pred = pred.detach().numpy()
            # x = pred[:,:,0]
            # y = pred[:,:,1]
            # x = float(x)
            # y = float(y)
            # shift = [y, x]
            # shift = np.array(shift)
            #pre_score=output['object_presence_score']
            start_time = time.time()
            out = tracker.track_predict(image,image_l,info) #根据第一张搜索区域
            score=out['object_presence_score']
            # f = open("/home/lcl_d/zhaoxingle/pytracking_tomp/tomp_predict/pytracking/scores.txt", 'a')
            # f.write(frame_path.split('/')[-3]+"--->"+"frame_num:"+str(frame_num+1)+"--->"+"score:"+str(score)+'\n')
            # f.close()
            #防止位移过大
            if(self.correct(out['target_bbox'],track_id)):
                out['object_presence_score']=0.6
                score=out['object_presence_score']
            #flag_0 = False
            #flag_1 = False

            # if(score>0.8):
            #     count=0
            if(score<0.7 and count<15):
                if(frame_num>=11):
                    #if(count<10):
                    #     a=np.array([track_id[frame_num-10],track_id[frame_num-9],track_id[frame_num-8],track_id[frame_num-7],track_id[frame_num-6],track_id[frame_num-5],track_id[frame_num-4],track_id[frame_num-3],track_id[frame_num-2],track_id[frame_num-1]])
                    #     b=np.array([track_id[frame_num-11],track_id[frame_num-10],track_id[frame_num-9],track_id[frame_num-8],track_id[frame_num-7],track_id[frame_num-6],track_id[frame_num-5],track_id[frame_num-4],track_id[frame_num-3],track_id[frame_num-2]])
                    #     dd=(a-b)
                    #     d=np.mean(dd,0)
                    #     e=dd*d
                    #     dx=d[0]
                    #     dy=d[1]
                    #     flag1=False
                    #     flag2=False
                    #     flag1_y=False
                    #     flag2_y=False

                    #     t1=track_id[frame_num-7]
                    #     t2=track_id[frame_num-8]
                    #     t3=track_id[frame_num-9]
                    #     var0=np.var([t1[0],t2[0],t3[0]])
                    #     var1=np.var([t1[1], t2[1], t3[1]])
                    #     if(var0<0.01):
                    #         flag_0=True
                    #     if (var1 < 0.01):
                    #         flag_1 = True

                    #     if(dx*dd[-3][0]<0):
                    #         flag1=True
                    #         if(abs(dx)<0.5):
                    #             track_id[frame_num-3][0]=track_id[frame_num-4][0]+dx*3
                    #             dd[-3][0]=dd[-3][0]+dx*3
                    #         else:
                    #             track_id[frame_num-3][0]=track_id[frame_num-4][0]+dx
                    #             dd[-3][0]=dd[-3][0]+dx
                    #     if(dx*dd[-2][0]<0):
                    #         flag2=True
                    #         if(abs(dx)<0.5):
                    #             track_id[frame_num-2][0]=track_id[frame_num-3][0]+dx*3
                    #             dd[-2][0]=dd[-2][0]+dx*3
                    #         else:
                    #             track_id[frame_num-2][0]=track_id[frame_num-3][0]+dx
                    #             dd[-2][0]=dd[-2][0]+dx
                    #     if(dx*dd[-1][0]<0 or flag2&flag1):
                    #         if(abs(dx)<0.5):
                    #             track_id[frame_num-1][0]=track_id[frame_num-2][0]+dx*3
                    #             dd[-1][0]=dd[-1][0]+dx*3
                    #         else:
                    #             track_id[frame_num-1][0]=track_id[frame_num-2][0]+dx
                    #             dd[-1][0]=dd[-1][0]+dx
                    #     if(dy*dd[-3][1]<=0):
                    #         flag1_y=True
                    #         if(abs(dy)<0.5):
                    #             track_id[frame_num-3][1]=track_id[frame_num-4][1]+dy*3
                    #             dd[-3][1]=dd[-3][1]+dx*3
                    #         else:
                    #             track_id[frame_num-3][1]=track_id[frame_num-4][1]+dy
                    #             dd[-3][1]=dd[-3][1]+dx
                    #     if(dy*dd[-2][1]<=0):
                    #         flag2_y=True
                    #         if(abs(dy)<0.5):
                    #             track_id[frame_num-2][1]=track_id[frame_num-3][1]+dy*3
                    #             dd[-2][1]=dd[-2][1]+dx*3
                    #         else:
                    #             track_id[frame_num-2][1]=track_id[frame_num-3][1]+dy
                    #             dd[-2][1]=dd[-2][1]+dx
                    #     if(dy*dd[-1][1]<=0 or flag2_y&flag1_y):
                    #         if(abs(dy)<0.5):
                    #             track_id[frame_num-1][1]=track_id[frame_num-2][1]+dy*3
                    #             dd[-1][1]=dd[-1][1]+dx*3
                    #         else:
                    #             track_id[frame_num-1][1]=track_id[frame_num-2][1]+dy
                    #             dd[-1][1]=dd[-1][1]+dx
                    #     t1=track_id[frame_num-1]
                    #     t2=track_id[frame_num-2]
                    #     t3=track_id[frame_num-3]

                    # elif(count<10):
                    a=np.array([track_id[frame_num-10],track_id[frame_num-9],track_id[frame_num-8],track_id[frame_num-7],track_id[frame_num-6],track_id[frame_num-5],track_id[frame_num-4],track_id[frame_num-3],track_id[frame_num-2],track_id[frame_num-1]])
                    b=np.array([track_id[frame_num-11],track_id[frame_num-10],track_id[frame_num-9],track_id[frame_num-8],track_id[frame_num-7],track_id[frame_num-6],track_id[frame_num-5],track_id[frame_num-4],track_id[frame_num-3],track_id[frame_num-2]])
                    dd=(a-b)
                    d=np.mean(dd,0)
                    e=dd*d
                    dx1=d[0]
                    dy1=d[1]
                    flag1=False
                    flag2=False
                    flag1_y=False
                    flag2_y=False
                    t1=track_id[frame_num-7]
                    t2=track_id[frame_num-8]
                    t3=track_id[frame_num-9]
                    var0=np.var([t1[0],t2[0],t3[0]])
                    var1=np.var([t1[1], t2[1], t3[1]])

                    if(var0<0.01):
                        flag_0=True
                    if (var1 < 0.01):
                        flag_1 = True

                    # if(not flag_0 and dx*dd[-3][0]<0):
                    #     flag1=True
                    #     if(abs(dx)<0.5):
                    #         track_id[frame_num-3][0]=track_id[frame_num-4][0]+dx*3
                    #         dd[-3][0]=dd[-3][0]+dx*3
                    #     else:
                    #         track_id[frame_num-3][0]=track_id[frame_num-4][0]+dx
                    #         dd[-3][0]=dd[-3][0]+dx
                    # if(not flag_0 and dx*dd[-2][0]<0):
                    #     flag2=True
                    #     if(abs(dx)<0.5):
                    #         track_id[frame_num-2][0]=track_id[frame_num-3][0]+dx*3
                    #         dd[-2][0]=dd[-2][0]+dx*3
                    #     else:
                    #         track_id[frame_num-2][0]=track_id[frame_num-3][0]+dx
                    #         dd[-2][0]=dd[-2][0]+dx
                    # if(not flag_0 and (dx*dd[-1][0]<0 or flag2&flag1)):
                    #     if(abs(dx)<0.5):
                    #         track_id[frame_num-1][0]=track_id[frame_num-2][0]+dx*3
                    #         dd[-1][0]=dd[-1][0]+dx*3
                    #     else:
                    #         track_id[frame_num-1][0]=track_id[frame_num-2][0]+dx
                    #         dd[-1][0]=dd[-1][0]+dx
                    # if(not flag_1 and dy*dd[-3][1]<0):
                    #     flag1_y=True
                    #     if(abs(dy)<0.5):
                    #         track_id[frame_num-3][1]=track_id[frame_num-4][1]+dy*3
                    #         dd[-3][1]=dd[-3][1]+dx*3
                    #     else:
                    #         track_id[frame_num-3][1]=track_id[frame_num-4][1]+dy
                    #         dd[-3][1]=dd[-3][1]+dx
                    # if(not flag_1 and dy*dd[-2][1]<0):
                    #     flag2_y=True
                    #     if(abs(dy)<0.5):
                    #         track_id[frame_num-2][1]=track_id[frame_num-3][1]+dy*3
                    #         dd[-2][1]=dd[-2][1]+dx*3
                    #     else:
                    #         track_id[frame_num-2][1]=track_id[frame_num-3][1]+dy
                    #         dd[-2][1]=dd[-2][1]+dx
                    # if(not flag_1 and (dy*dd[-1][1]<0 or flag2_y&flag1_y)):
                        # if(abs(dy)<0.5):
                        #     track_id[frame_num-1][1]=track_id[frame_num-2][1]+dy*3
                        #     dd[-1][1]=dd[-1][1]+dx*3
                        # else:
                        #     track_id[frame_num-1][1]=track_id[frame_num-2][1]+dy
                        #     dd[-1][1]=dd[-1][1]+dx
                    t1=track_id[frame_num-1]
                    t2=track_id[frame_num-2]
                    t3=track_id[frame_num-3]
                    t4=track_id[frame_num-4]

                    
                    #线性拟合                    
                    a=np.array([t4,t3,t2,t1])
                    # b=np.array([t4,t3,t2])
                    # dd=(a-b)
                    # d=np.mean(dd,0)
                    # dx2=d[0]
                    # dy2=d[1]
                    # for i in range(-3,0):
                    #     if ((dd[i][0]*d[0]<0 and abs(dd[i][0])>0.5) and abs(d[0])>0.5):
                    #         a[i][0] = a[i][0]+d[0]*1
                    #     # else:
                    #     #     a[i][0] = a[i][0]+d[0]*0.5
                    
                    #     if (dd[i][1]*d[1]<0 and abs(dd[i][0])>0.5) and abs(d[1])>0.5):
                    #         a[i][1] = a[i][1]+d[1]*1
                    # for i in range(-3,0):
                    #     if (dd[i][0]*d[0]<0 and abs(d[0])>0.5):
                    #         a[i][0] = a[i-1][0]+d[0]*1
                    #     # else:
                    #     #     a[i][0] = a[i][0]+d[0]*0.5
                    
                    #     if (dd[i][1]*d[1]<0 and abs(d[1])>0.5):
                    #         a[i][1] = a[i-1][1]+d[1]*1
                        # else:
                        #     a[i][1] = a[i][1]+d[1]*0.5
                    for i in range(-3,0):
                        if (abs(dd[i][0])<abs(d[0]) and abs(d[0])>0.3):
                            a[i][0] = a[i-1][0]+d[0]*1
                            track_id[frame_num+i][0]=a[i][0]
                        # else:
                        #     a[i][0] = a[i][0]+d[0]*0.5
                
                        if (abs(dd[i][1])<abs(d[1]) and abs(d[1])>0.3):
                            a[i][1] = a[i-1][1]+d[1]*1
                            track_id[frame_num+i][1]=a[i][1]
                    #inp_np=[t3,t2,t1]
                    
                    # 最小二乘法拟合
                    # x=np.array(a[:,0])
                    # y=np.array(a[:,1])
                    # n = len(x)
                    # x_0 = np.ones(n)
                    # x_1 = x
                    # x_2 = x**2
                    # x_3 = x**3
                    # x_4 = x**4
                    # x_5 = x**5
                    # x_6 = x**6

                    # X = np.stack((x_0, x_1, x_2, x_3, x_4, x_5, x_6), axis=1)
                    # XT = np.transpose(X)
                    # Y = np.transpose(y)

                    # XTX_inv = np.linalg.inv(np.dot(XT, X))
                    # XTY = np.dot(XT, Y)
                    # b = np.dot(XTX_inv, XTY)
                    
                    # import math

                    # def get_distance_point2line(point, line_ab):
                    #     """
                    #     Args:
                    #         point: [x0, y0]
                    #         line_ab: [k, b]
                    #     """
                    #     k, b = line_ab
                    #     distance = abs(k * point[0] - point[1] + b) / math.sqrt(k**2 + 1)
                    #     return distance


                    # dis = get_distance_point2line(point, line)


                    inp_np=a[-3:]
                    inp_np = np.array(inp_np)
                    inp_np = torch.tensor(inp_np)#8*2
                    inp_np = inp_np.unsqueeze(0)
                    inp_speed = np.concatenate((np.zeros((inp_np.shape[0],1,2)),inp_np[:,1:,0:2] - inp_np[:, :-1, 0:2]),1)
                    inp_norm=np.concatenate((inp_np,inp_speed),2)
                    inp = inp_norm[:, 1:, 2:4]
                    src_att = torch.ones((inp.shape[0], 1, inp.shape[1]))
                    start_of_seq = torch.Tensor([0, 0, 1]).unsqueeze(0).unsqueeze(1).repeat(inp.shape[0], 1, 1)
                    #start_of_seq = torch.Tensor([0,0,0,0,0,0,0,1]).unsqueeze(0).unsqueeze(1).repeat(inp.shape[0], 1, 1)
                    dec_inp = start_of_seq
                    trg_att =[[True]]
                    inp = np.float32(inp)
                    dec_inp = np.float32(dec_inp) #torch.Size([1, 2, 3])
                    src_att = np.float32(src_att)
                    inp = torch.tensor(inp)
                    inp_norm = torch.tensor(inp_norm)
                    dec_inp = torch.tensor(dec_inp)
                    src_att = torch.tensor(src_att)#torch.Size([1, 1, 7])
                    trg_att = torch.tensor(trg_att)
                    trg_att = trg_att.unsqueeze(0)        
                    result = model(inp, dec_inp, src_att, trg_att)
                    dec_inp = torch.cat((dec_inp, result[:, -1:, :]),  1)
                    pred = dec_inp[:, 1:, 0:2] + inp_norm[:, -1:, 0:2]
                    pred = pred.detach().numpy()
                    x = pred[:,:,0]
                    y = pred[:,:,1]
                    x = float(x)
                    y = float(y)
                    #flag0如果未true,代表变化幅度很小
                    # if(flag_0):
                    #     if(d[0]<0):
                    #         x=float(inp_np[-1][-1][0]-0.1)
                    #     else:
                    #         x=float(inp_np[-1][-1][0]+0.1)
                    # if (flag_1):
                    #     if(d[1]<0):
                    #         y=float(inp_np[-1][-1][1]-0.1)
                    #     else:
                    #         y=float(inp_np[-1][-1][1]+0.1)
                    if(flag_0):
                            x=float(inp_np[-1][-1][0])
                    if (flag_1):
                            y=float(inp_np[-1][-1][1])
                    w=prev_output['target_bbox'][2]
                    h=prev_output['target_bbox'][3]
                    out['target_bbox']=[x-w/2,y-h/2,w,h]
                    out['object_presence_score']=0.9
                    shift = [y, x]
                    shift = np.array(shift)
                    shift=torch.tensor(shift)
                    info['shift']=shift
                    out['shift']=shift
                    count=count+1
                    #out['target_bbox']=
                    #out = tracker.track(image,info)
                    #del info['shift']
                    #t1=track_id[frame_num-1]
                    #bbox_size = out['target_bbox']
                    #center_x = bbox_size[0] + 0.5 * bbox_size[2]
                    #center_y = bbox_size[1] + 0.5 * bbox_size[3]
                    #track_id[frame_num]=[center_x,center_y]
                    track_id[frame_num]=[x,y]
                    # dx=center_x-track_id[frame_num-1][0]
                    # dy=center_y-track_id[frame_num-1][1]
                    # dx_track[frame_num]=[dx,dy]
                        # if(out['object_presence_score']<0.5):
                        #     count=count+1
                        # if(count==4):
                        #     center_x = bbox_size[0] + 0.5 * bbox_size[2]
                        #     center_y = bbox_size[1] + 0.5 * bbox_size[3]
                        #     track_id[frame_num]=[center_x,center_y]
                        #     count=count+1
                else:
                    bbox_size = out['target_bbox']
                    center_x = bbox_size[0] + 0.5 * bbox_size[2]
                    center_y = bbox_size[1] + 0.5 * bbox_size[3]
                    track_id[frame_num]=[center_x,center_y]
            else: #更新轨迹
                bbox_size = out['target_bbox']
                center_x = bbox_size[0] + 0.5 * bbox_size[2]
                center_y = bbox_size[1] + 0.5 * bbox_size[3]
                track_id[frame_num]=[center_x,center_y]
                count=0
                flag_0 = False
                flag_1 = False

            prev_output = OrderedDict(out)
            _store_outputs(out, {'time': time.time() - start_time})
            segmentation = out['segmentation'] if 'segmentation' in out else None
            if self.visdom is not None:
                tracker.visdom_draw_tracking(image, out['target_bbox'], segmentation)
            elif tracker.params.visualization:
                self.visualize(image, out['target_bbox'], segmentation)
        for key in ['target_bbox', 'segmentation']:
            if key in output and len(output[key]) <= 1:
                output.pop(key)

        output['image_shape'] = image.shape[:2]
        output['object_presence_score_threshold'] = tracker.params.get('object_presence_score_threshold', 0.55)

        return output

    def _track_sequence(self, tracker, seq, init_info):
        # Define outputs
        # Each field in output is a list containing tracker prediction for each frame.

        # In case of single object tracking mode:
        # target_bbox[i] is the predicted bounding box for frame i
        # time[i] is the processing time for frame i
        # segmentation[i] is the segmentation mask for frame i (numpy array)

        # In case of multi object tracking mode:
        # target_bbox[i] is an OrderedDict, where target_bbox[i][obj_id] is the predicted box for target obj_id in
        # frame i
        # time[i] is either the processing time for frame i, or an OrderedDict containing processing times for each
        # object in frame i
        # segmentation[i] is the multi-label segmentation mask for frame i (numpy array)

        output = {'target_bbox': [],
                  'time': [],
                  'segmentation': [],
                  'object_presence_score': []}

        def _store_outputs(tracker_out: dict, defaults=None):
            defaults = {} if defaults is None else defaults
            for key in output.keys():
                val = tracker_out.get(key, defaults.get(key, None))
                if key in tracker_out or val is not None:
                    output[key].append(val)

        # Initialize
        image = self._read_image(seq.frames[0])
        if tracker.params.visualization and self.visdom is None:
            self.visualize(image, init_info.get('init_bbox'))

        start_time = time.time()
        out = tracker.initialize(image, init_info)
        if out is None:
            out = {}

        prev_output = OrderedDict(out)

        init_default = {'target_bbox': init_info.get('init_bbox'),
                        'time': time.time() - start_time,
                        'segmentation': init_info.get('init_mask'),
                        'object_presence_score': 1.}

        _store_outputs(out, init_default)

        for frame_num, frame_path in enumerate(seq.frames[1:], start=1):
            while True:
                if not self.pause_mode:
                    break
                elif self.step:
                    self.step = False
                    break
                else:
                    time.sleep(0.1)

            # image = self._read_image(frame_path)

            # lst_url = frame_path.split('/')
            # lst_url.pop(-1)
            # pre = '/'.join(lst_url)
            
            # jpg_name=frame_path.split('/')[-1]
            # a=int(jpg_name.split('.')[-2])
            
            # frame_path_l=os.path.join(pre,'{:04}.jpg'.format(a-1))

            # image_l = self._read_image(frame_path_l)


            image = self._read_image(frame_path)

            lst_url = frame_path.split('/')
            lst_url.pop(-1)
            pre = '/'.join(lst_url)
            jpg_name=frame_path.split('/')[-1]
            
            # if(seq.dataset=='SV248A10'):
            #     frame_path_l=os.path.join(pre,'{:06}.tiff'.format(int(jpg_name.split('.')[-2])-1))
            # else:
            #     a=int(jpg_name.split('.')[-2])
            #     frame_path_l=os.path.join(pre,'{:04}.jpg'.format(a-1)) 
            
            if(seq.dataset=='SV248A10'):
                frame_path_l=os.path.join(pre,'{:06}.tiff'.format(int(jpg_name.split('.')[-2])-1))
            else:
                a=int(jpg_name.split('.')[-2])
                frame_path_l=os.path.join(pre,'{:04}.jpg'.format(a-1)) #sot

            image_l = self._read_image(frame_path_l)

            start_time = time.time()

            info = seq.frame_info(frame_num)
            info['previous_output'] = prev_output

            out = tracker.track(image,image_l,info)
            prev_output = OrderedDict(out)
            _store_outputs(out, {'time': time.time() - start_time})

            segmentation = out['segmentation'] if 'segmentation' in out else None
            if self.visdom is not None:
                tracker.visdom_draw_tracking(image, out['target_bbox'], segmentation)
            elif tracker.params.visualization:
                self.visualize(image, out['target_bbox'], segmentation)

        for key in ['target_bbox', 'segmentation']:
            if key in output and len(output[key]) <= 1:
                output.pop(key)

        output['image_shape'] = image.shape[:2]
        output['object_presence_score_threshold'] = tracker.params.get('object_presence_score_threshold', 0.55)

        return output
    def run_video(self, videofilepath, optional_box=None, debug=None, visdom_info=None, save_results=False):
        """Run the tracker with the video file.
        args:
            debug: Debug level.
        """

        params = self.get_parameters()

        debug_ = debug
        if debug is None:
            debug_ = getattr(params, 'debug', 0)
        params.debug = debug_

        params.tracker_name = self.name
        params.param_name = self.parameter_name
        self._init_visdom(visdom_info, debug_)

        multiobj_mode = getattr(params, 'multiobj_mode', getattr(self.tracker_class, 'multiobj_mode', 'default'))

        if multiobj_mode == 'default':
            tracker = self.create_tracker(params)
            if hasattr(tracker, 'initialize_features'):
                tracker.initialize_features()

        elif multiobj_mode == 'parallel':
            tracker = MultiObjectWrapper(self.tracker_class, params, self.visdom, fast_load=True)
        else:
            raise ValueError('Unknown multi object mode {}'.format(multiobj_mode))

        assert os.path.isfile(videofilepath), "Invalid param {}".format(videofilepath)
        ", videofilepath must be a valid videofile"

        output_boxes = []

        cap = cv.VideoCapture(videofilepath)
        display_name = 'Display: ' + tracker.params.tracker_name
        cv.namedWindow(display_name, cv.WINDOW_NORMAL | cv.WINDOW_KEEPRATIO)
        cv.resizeWindow(display_name, 960, 720)
        success, frame = cap.read()
        cv.imshow(display_name, frame)

        def _build_init_info(box):
            return {'init_bbox': OrderedDict({1: box}), 'init_object_ids': [1, ], 'object_ids': [1, ],
                    'sequence_object_ids': [1, ]}

        if success is not True:
            print("Read frame from {} failed.".format(videofilepath))
            exit(-1)
        if optional_box is not None:
            assert isinstance(optional_box, (list, tuple))
            assert len(optional_box) == 4, "valid box's foramt is [x,y,w,h]"
            tracker.initialize(frame, _build_init_info(optional_box))
            output_boxes.append(optional_box)
        else:
            while True:
                # cv.waitKey()
                frame_disp = frame.copy()

                cv.putText(frame_disp, 'Select target ROI and press ENTER', (20, 30), cv.FONT_HERSHEY_COMPLEX_SMALL,
                           1.5, (0, 0, 0), 1)

                x, y, w, h = cv.selectROI(display_name, frame_disp, fromCenter=False)
                init_state = [x, y, w, h]
                tracker.initialize(frame, _build_init_info(init_state))
                output_boxes.append(init_state)
                break

        while True:
            ret, frame = cap.read()

            if frame is None:
                break

            frame_disp = frame.copy()

            # Draw box
            out = tracker.track(frame)
            state = [int(s) for s in out['target_bbox'][1]]
            output_boxes.append(state)

            cv.rectangle(frame_disp, (state[0], state[1]), (state[2] + state[0], state[3] + state[1]),
                         (0, 255, 0), 5)

            font_color = (0, 0, 0)
            cv.putText(frame_disp, 'Tracking!', (20, 30), cv.FONT_HERSHEY_COMPLEX_SMALL, 1,
                       font_color, 1)
            cv.putText(frame_disp, 'Press r to reset', (20, 55), cv.FONT_HERSHEY_COMPLEX_SMALL, 1,
                       font_color, 1)
            cv.putText(frame_disp, 'Press q to quit', (20, 80), cv.FONT_HERSHEY_COMPLEX_SMALL, 1,
                       font_color, 1)

            # Display the resulting frame
            cv.imshow(display_name, frame_disp)
            key = cv.waitKey(1)
            if key == ord('q'):
                break
            elif key == ord('r'):
                ret, frame = cap.read()
                frame_disp = frame.copy()

                cv.putText(frame_disp, 'Select target ROI and press ENTER', (20, 30), cv.FONT_HERSHEY_COMPLEX_SMALL, 1.5,
                           (0, 0, 0), 1)

                cv.imshow(display_name, frame_disp)
                x, y, w, h = cv.selectROI(display_name, frame_disp, fromCenter=False)
                init_state = [x, y, w, h]
                tracker.initialize(frame, _build_init_info(init_state))
                output_boxes.append(init_state)

        # When everything done, release the capture
        cap.release()
        cv.destroyAllWindows()

        if save_results:
            if not os.path.exists(self.results_dir):
                os.makedirs(self.results_dir)
            video_name = Path(videofilepath).stem
            base_results_path = os.path.join(self.results_dir, 'video_{}'.format(video_name))

            tracked_bb = np.array(output_boxes).astype(int)
            bbox_file = '{}.txt'.format(base_results_path)
            np.savetxt(bbox_file, tracked_bb, delimiter='\t', fmt='%d')

    def run_webcam(self, debug=None, visdom_info=None):
        """Run the tracker with the webcam.
        args:
            debug: Debug level.
        """

        params = self.get_parameters()

        debug_ = debug
        if debug is None:
            debug_ = getattr(params, 'debug', 0)
        params.debug = debug_

        params.tracker_name = self.name
        params.param_name = self.parameter_name

        self._init_visdom(visdom_info, debug_)

        multiobj_mode = getattr(params, 'multiobj_mode', getattr(self.tracker_class, 'multiobj_mode', 'default'))

        if multiobj_mode == 'default':
            tracker = self.create_tracker(params)
        elif multiobj_mode == 'parallel':
            tracker = MultiObjectWrapper(self.tracker_class, params, self.visdom, fast_load=True)
        else:
            raise ValueError('Unknown multi object mode {}'.format(multiobj_mode))

        class UIControl:
            def __init__(self):
                self.mode = 'init'  # init, select, track
                self.target_tl = (-1, -1)
                self.target_br = (-1, -1)
                self.new_init = False

            def mouse_callback(self, event, x, y, flags, param):
                if event == cv.EVENT_LBUTTONDOWN and self.mode == 'init':
                    self.target_tl = (x, y)
                    self.target_br = (x, y)
                    self.mode = 'select'
                elif event == cv.EVENT_MOUSEMOVE and self.mode == 'select':
                    self.target_br = (x, y)
                elif event == cv.EVENT_LBUTTONDOWN and self.mode == 'select':
                    self.target_br = (x, y)
                    self.mode = 'init'
                    self.new_init = True

            def get_tl(self):
                return self.target_tl if self.target_tl[0] < self.target_br[0] else self.target_br

            def get_br(self):
                return self.target_br if self.target_tl[0] < self.target_br[0] else self.target_tl

            def get_bb(self):
                tl = self.get_tl()
                br = self.get_br()

                bb = [min(tl[0], br[0]), min(tl[1], br[1]), abs(br[0] - tl[0]), abs(br[1] - tl[1])]
                return bb

        ui_control = UIControl()
        cap = cv.VideoCapture(0)
        display_name = 'Display: ' + self.name
        cv.namedWindow(display_name, cv.WINDOW_NORMAL | cv.WINDOW_KEEPRATIO)
        cv.resizeWindow(display_name, 960, 720)
        cv.setMouseCallback(display_name, ui_control.mouse_callback)

        next_object_id = 1
        sequence_object_ids = []
        prev_output = OrderedDict()
        while True:
            # Capture frame-by-frame
            ret, frame = cap.read()
            frame_disp = frame.copy()

            info = OrderedDict()
            info['previous_output'] = prev_output

            if ui_control.new_init:
                ui_control.new_init = False
                init_state = ui_control.get_bb()

                info['init_object_ids'] = [next_object_id, ]
                info['init_bbox'] = OrderedDict({next_object_id: init_state})
                sequence_object_ids.append(next_object_id)

                next_object_id += 1

            # Draw box
            if ui_control.mode == 'select':
                cv.rectangle(frame_disp, ui_control.get_tl(), ui_control.get_br(), (255, 0, 0), 2)

            if len(sequence_object_ids) > 0:
                info['sequence_object_ids'] = sequence_object_ids
                out = tracker.track(frame, info)
                prev_output = OrderedDict(out)

                if 'segmentation' in out:
                    frame_disp = overlay_mask(frame_disp, out['segmentation'])

                if 'target_bbox' in out:
                    for obj_id, state in out['target_bbox'].items():
                        state = [int(s) for s in state]
                        cv.rectangle(frame_disp, (state[0], state[1]), (state[2] + state[0], state[3] + state[1]),
                                     _tracker_disp_colors[obj_id], 5)

            # Put text
            font_color = (0, 0, 0)
            cv.putText(frame_disp, 'Select target', (20, 30), cv.FONT_HERSHEY_COMPLEX_SMALL, 1, font_color, 1)
            cv.putText(frame_disp, 'Press r to reset', (20, 55), cv.FONT_HERSHEY_COMPLEX_SMALL, 1,
                       font_color, 1)
            cv.putText(frame_disp, 'Press q to quit', (20, 85), cv.FONT_HERSHEY_COMPLEX_SMALL, 1,
                       font_color, 1)

            # Display the resulting frame
            cv.imshow(display_name, frame_disp)
            key = cv.waitKey(1)
            if key == ord('q'):
                break
            elif key == ord('r'):
                next_object_id = 1
                sequence_object_ids = []
                prev_output = OrderedDict()

                info = OrderedDict()

                info['object_ids'] = []
                info['init_object_ids'] = []
                info['init_bbox'] = OrderedDict()
                tracker.initialize(frame, info)
                ui_control.mode = 'init'

        # When everything done, release the capture
        cap.release()
        cv.destroyAllWindows()

    def run_vot2020(self, debug=None, visdom_info=None):
        params = self.get_parameters()
        params.tracker_name = self.name
        params.param_name = self.parameter_name
        params.run_id = self.run_id

        debug_ = debug
        if debug is None:
            debug_ = getattr(params, 'debug', 0)

        if debug is None:
            visualization_ = getattr(params, 'visualization', False)
        else:
            visualization_ = True if debug else False

        params.visualization = visualization_
        params.debug = debug_

        self._init_visdom(visdom_info, debug_)

        tracker = self.create_tracker(params)
        tracker.initialize_features()

        output_segmentation = tracker.predicts_segmentation_mask()

        import pytracking.evaluation.vot2020 as vot

        def _convert_anno_to_list(vot_anno):
            vot_anno = [vot_anno[0], vot_anno[1], vot_anno[2], vot_anno[3]]
            return vot_anno

        def _convert_image_path(image_path):
            return image_path

        """Run tracker on VOT."""

        if output_segmentation:
            handle = vot.VOT("mask")
        else:
            handle = vot.VOT("rectangle")

        vot_anno = handle.region()

        image_path = handle.frame()
        if not image_path:
            return
        image_path = _convert_image_path(image_path)

        image = self._read_image(image_path)

        if output_segmentation:
            vot_anno_mask = vot.make_full_size(vot_anno, (image.shape[1], image.shape[0]))
            bbox = masks_to_bboxes(torch.from_numpy(vot_anno_mask), fmt='t').squeeze().tolist()
        else:
            bbox = _convert_anno_to_list(vot_anno)
            vot_anno_mask = None

        out = tracker.initialize(image, {'init_mask': vot_anno_mask, 'init_bbox': bbox})

        if out is None:
            out = {}
        prev_output = OrderedDict(out)

        # Track
        while True:
            image_path = handle.frame()
            if not image_path:
                break
            image_path = _convert_image_path(image_path)

            image = self._read_image(image_path)

            info = OrderedDict()
            info['previous_output'] = prev_output

            out = tracker.track(image, info)
            prev_output = OrderedDict(out)

            if output_segmentation:
                pred = out['segmentation'].astype(np.uint8)
            else:
                state = out['target_bbox']
                pred = vot.Rectangle(*state)
            handle.report(pred, 1.0)

            segmentation = out['segmentation'] if 'segmentation' in out else None
            if self.visdom is not None:
                tracker.visdom_draw_tracking(image, out['target_bbox'], segmentation)
            elif tracker.params.visualization:
                self.visualize(image, out['target_bbox'], segmentation)


    def run_vot(self, debug=None, visdom_info=None):
        params = self.get_parameters()
        params.tracker_name = self.name
        params.param_name = self.parameter_name
        params.run_id = self.run_id

        debug_ = debug
        if debug is None:
            debug_ = getattr(params, 'debug', 0)

        if debug is None:
            visualization_ = getattr(params, 'visualization', False)
        else:
            visualization_ = True if debug else False

        params.visualization = visualization_
        params.debug = debug_

        self._init_visdom(visdom_info, debug_)

        tracker = self.create_tracker(params)
        tracker.initialize_features()

        import pytracking.evaluation.vot as vot

        def _convert_anno_to_list(vot_anno):
            vot_anno = [vot_anno[0][0][0], vot_anno[0][0][1], vot_anno[0][1][0], vot_anno[0][1][1],
                        vot_anno[0][2][0], vot_anno[0][2][1], vot_anno[0][3][0], vot_anno[0][3][1]]
            return vot_anno

        def _convert_image_path(image_path):
            image_path_new = image_path[20:- 2]
            return "".join(image_path_new)

        """Run tracker on VOT."""

        handle = vot.VOT("polygon")

        vot_anno_polygon = handle.region()
        vot_anno_polygon = _convert_anno_to_list(vot_anno_polygon)

        init_state = convert_vot_anno_to_rect(vot_anno_polygon, tracker.params.vot_anno_conversion_type)

        image_path = handle.frame()
        if not image_path:
            return
        image_path = _convert_image_path(image_path)

        image = self._read_image(image_path)
        tracker.initialize(image, {'init_bbox': init_state})

        # Track
        while True:
            image_path = handle.frame()
            if not image_path:
                break
            image_path = _convert_image_path(image_path)

            image = self._read_image(image_path)
            out = tracker.track(image)
            state = out['target_bbox']

            handle.report(vot.Rectangle(state[0], state[1], state[2], state[3]))

            segmentation = out['segmentation'] if 'segmentation' in out else None
            if self.visdom is not None:
                tracker.visdom_draw_tracking(image, out['target_bbox'], segmentation)
            elif tracker.params.visualization:
                self.visualize(image, out['target_bbox'], segmentation)

    def get_parameters(self):
        """Get parameters."""
        param_module = importlib.import_module('pytracking.parameter.{}.{}'.format(self.name, self.parameter_name))
        params = param_module.parameters()
        return params


    def init_visualization(self):
        self.pause_mode = False
        self.fig, self.ax = plt.subplots(1)
        self.fig.canvas.mpl_connect('key_press_event', self.press)
        plt.tight_layout()


    def visualize(self, image, state, segmentation=None):
        self.ax.cla()
        self.ax.imshow(image)
        if segmentation is not None:
            self.ax.imshow(segmentation, alpha=0.5)

        if isinstance(state, (OrderedDict, dict)):
            boxes = [v for k, v in state.items()]
        else:
            boxes = (state,)

        for i, box in enumerate(boxes, start=1):
            col = _tracker_disp_colors[i]
            col = [float(c) / 255.0 for c in col]
            rect = patches.Rectangle((box[0], box[1]), box[2], box[3], linewidth=1, edgecolor=col, facecolor='none')
            self.ax.add_patch(rect)

        if getattr(self, 'gt_state', None) is not None:
            gt_state = self.gt_state
            rect = patches.Rectangle((gt_state[0], gt_state[1]), gt_state[2], gt_state[3], linewidth=1, edgecolor='g', facecolor='none')
            self.ax.add_patch(rect)
        self.ax.set_axis_off()
        self.ax.axis('equal')
        draw_figure(self.fig)

        if self.pause_mode:
            keypress = False
            while not keypress:
                keypress = plt.waitforbuttonpress()

    def reset_tracker(self):
        pass

    def press(self, event):
        if event.key == 'p':
            self.pause_mode = not self.pause_mode
            print("Switching pause mode!")
        elif event.key == 'r':
            self.reset_tracker()
            print("Resetting target pos to gt!")

    def _read_image(self, image_file: str):
        im = cv.imread(image_file)
        return cv.cvtColor(im, cv.COLOR_BGR2RGB)



