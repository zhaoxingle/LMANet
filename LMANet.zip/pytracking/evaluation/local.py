from pytracking.evaluation.environment import EnvSettings

def local_env_settings():
    settings = EnvSettings()

    # Set your local paths here.

    settings.davis_dir = ''
    settings.got10k_path = ''
    settings.got_packed_results_path = ''
    settings.got_reports_path = ''
    settings.lasot_extension_subset_path = ''
    settings.lasot_path = ''
    settings.network_path = '/home/lcl_d/zhaoxingle/pytracking_tomp/pytracking/pytracking/networks/'    # Where tracking networks are stored.
    settings.nfs_path = ''
    settings.otb_path = ''
    settings.oxuva_path = ''
    settings.result_plot_path = '/media/data2/zhaoxingle/result_sot/tomp_add_motion_tempral_ffn2_R_epoch_30_new_predict_0.7_15_all_viso/'
    settings.results_path = '/media/data2/zhaoxingle/xiaorong/result_satsot/tomp_add_motion_tempral_ffn2_R_epoch_30_predict_0.7_15_all_viso/results/'    # Where to store tracking results
    settings.satsot_path = '/media/data2/zhaoxingle/SatSOT'
    settings.segmentation_path = '/home/lcl_d/zhaoxingle/pytracking_tomp/pytracking/pytracking/segmentation_results/'
    settings.tn_packed_results_path = ''
    settings.tpl_path = ''
    settings.trackingnet_path = ''
    settings.uav_path = ''
    settings.viso_path = '/media/data2/zhaoxingle/sot'
    settings.vot_path = ''
    settings.youtubevos_dir = ''
    settings.SV248S_path = '/media/data2/zhaoxingle/SV248A10'

    return settings

