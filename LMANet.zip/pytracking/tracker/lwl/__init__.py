from .lwl import LWL


def get_tracker_class():
    return LWL