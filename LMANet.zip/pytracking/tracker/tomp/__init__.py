from .tomp import ToMP

def get_tracker_class():
    return ToMP