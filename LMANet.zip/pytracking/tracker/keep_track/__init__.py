from .keep_track import KeepTrack

def get_tracker_class():
    return KeepTrack