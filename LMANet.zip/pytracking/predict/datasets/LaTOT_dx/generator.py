import numpy
import numpy as np
import os

'''
产生轨迹
第几帧  序列数  物体中心x 物体中心y
'''
def readTxt(files):
    #filelist = os.listdir(files)
    filelist=[]    
    # for root, dirs, files in os.walk(files, topdown=False):
    #     if(root.split('/')[-3]=='LaTOT'):
    #         filelist.append(os.path.join(root,files[0]))
    #         print(filelist)
    # for i in range(len(filelist)):
    with open(r'/home/lcl_d/zhaoxingle/pytracking_tomp/1orign_tomp/pytracking/ltr/data_specs/train.txt') as f:
        filelist=f.read().splitlines()
    for i in range(2032): # 2023是指最长序列的帧数
        for file in filelist:
            file=file.strip() #'aircraft1'
            path=os.path.join(files,file,file+'.txt')
            in_file = open(path, encoding='utf-8')
            out_file = open('/home/lcl_d/zhaoxingle/pytracking_tomp/Trajectory-predict/datasets/LaTOT/train/train.txt', 'a', encoding='utf-8')
            lines = in_file.readlines()
            #line = lines[i].replace("\n","")
            #line = line.replace("\t","")
            if(i<len(lines)):
                if(lines[i][0]=="\n"):
                    continue
                if(lines[i][0]=="\t"):#:'\t\t\t\n'
                    continue
                if("\t" in lines[i]):
                    xywh=lines[i].split("\t")
                elif("," in lines[i]):
                    xywh=lines[i].split(",")
                else:
                    xywh=lines[i].split(" ")


                try:
                    x=float(xywh[0])
                except:
                    print(file)
                    print(xywh)
                y=float(xywh[1])
                w=float(xywh[2])
                h=float(xywh[3])
                x_center=round(x+w/2,6)
                y_center=round(y+h/2,6)
                seq = filelist.index(file)
                out_file.write(str(i*10) + ',' + str(seq) + ',' + str(x_center)+','+str(y_center)+'\n')



'''
产生轨迹
第几帧  序列数  物体中心dx 物体中心dy
'''
def readTxt_dx_dy(files):
    #filelist = os.listdir(files)
    filelist=[]    
    # for root, dirs, files in os.walk(files, topdown=False):
    #     if(root.split('/')[-3]=='LaTOT'):
    #         filelist.append(os.path.join(root,files[0]))
    #         print(filelist)
    # for i in range(len(filelist)):
    with open(r'/home/lcl_d/zhaoxingle/pytracking_tomp/1orign_tomp/pytracking/ltr/data_specs/train.txt') as f:
        filelist=f.read().splitlines()
    Last={}
    for i in range(2032): # 2023是指最长序列的帧数
        for file in filelist:
            file=file.strip() #'aircraft1'
            path=os.path.join(files,file,file+'.txt')
            in_file = open(path, encoding='utf-8')
            out_file = open('/home/lcl_d/zhaoxingle/pytracking_tomp/Trajectory-predict/datasets/LaTOT/train/train_dx.txt', 'a', encoding='utf-8')
            lines = in_file.readlines()
            #line = lines[i].replace("\n","")
            #line = line.replace("\t","")
            if(i<len(lines)):
                if(lines[i][0]=="\n"):
                    continue
                if(lines[i][0]=="\t"):#:'\t\t\t\n'
                    continue
                if("\t" in lines[i]):
                    xywh=lines[i].split("\t")
                elif("," in lines[i]):
                    xywh=lines[i].split(",")
                else:
                    xywh=lines[i].split(" ")

                try:
                    x=float(xywh[0])
                except:
                    print(file)
                    print(xywh)
                y=float(xywh[1])
                w=float(xywh[2])
                h=float(xywh[3])
                x_center=round(x+w/2,6)
                y_center=round(y+h/2,6)
                if(i==0):
                    seq = filelist.index(file)
                    Last[seq]=(x_center,y_center)
                    out_file.write(str(i*10) + ',' + str(seq) + ',' + str(x_center)+','+str(y_center)+'\n')
                else:
                    seq = filelist.index(file)
                    dx=round(x_center-Last[seq][0],6)
                    dy=round(y_center-Last[seq][1],6)
                    Last[seq]=(x_center,y_center)
                    out_file.write(str(i*10) + ',' + str(seq) + ',' + str(dx)+','+str(dy)+'\n')
if __name__=="__main__":
    readTxt_dx_dy('/media/data2/zhaoxingle/LaTOT/train/')